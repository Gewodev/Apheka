"""Text-to-speech via the Moonshine C API."""

import ctypes
import queue
import sys
import threading
import time
import traceback
import wave
from dataclasses import dataclass
from pathlib import Path
from typing import (
    Any,
    Dict,
    Iterable,
    Iterator,
    List,
    Mapping,
    Optional,
    Tuple,
    Union,
)

from moonshine_voice.download import (
    ProgressCallback,
    download_tts_assets,
    ensure_tts_voice_downloaded,
    normalize_moonshine_language_tag,
    tts_asset_cache_path,
    validate_tts_language,
    validate_tts_voice_known,
)
from moonshine_voice.errors import MoonshineAudioOutputError, MoonshineError
from moonshine_voice.moonshine_api import (
    MOONSHINE_HEADER_VERSION,
    MOONSHINE_TTS_CANCELLED,
    MOONSHINE_TTS_END_OF_STREAM,
    MOONSHINE_TTS_NEED_TEXT,
    _MoonshineLib,
    moonshine_options_array,
    moonshine_phonemes_to_speech_samples,
    moonshine_text_to_speech_samples,
    moonshine_tts_cancel,
    moonshine_tts_end_input,
    moonshine_tts_flush,
    moonshine_tts_is_streaming,
    moonshine_tts_next_chunk,
    moonshine_tts_push_text,
    moonshine_tts_split_utterances_list,
)
from moonshine_voice.voice_clone import VoiceClone


def split_say_utterances(text: str, language: Optional[str] = None) -> List[str]:
    """Split a passage into the utterances :meth:`TextToSpeech.say` speaks one at a time.

    Breaks on sentence terminators so the first clause can start playing while
    the rest synthesizes. Titles ("Dr. Smith") and initials ("J. R. R. Tolkien")
    do not end a sentence, and ``。！？؟।`` count as terminators without needing a
    following space. Pass ``language`` to pick up its abbreviation list; the
    language-neutral rules apply otherwise.
    """
    if not (text or "").strip():
        return []
    return moonshine_tts_split_utterances_list(text, language)


@dataclass
class TtsChunk:
    """One piece of streamed audio, small enough to start playing right away."""

    samples: List[float]
    sample_rate: int
    #: Text this chunk covers, or ``""`` when the engine cut on acoustic frames
    #: rather than a knowable span of characters.
    text: str
    #: Counts from 1, so a consumer can tell where one reply ends and the next
    #: begins.
    utterance_id: int
    #: ``True`` on the last chunk of an utterance.
    is_final: bool


class _ChunkPump:
    """Worker that delivers chunks to a callback as the native layer makes them.

    Used by :meth:`TextToSpeech.stream` and :meth:`TextToSpeech.say_stream`.
    Polls rather than blocking, because ``next_chunk`` returns immediately when
    no complete sentence has arrived yet and the text is coming from another
    thread.
    """

    def __init__(self, synthesizer: "TextToSpeech", handle: int, on_chunk: Any) -> None:
        self._synthesizer = synthesizer
        self._handle = handle
        self._on_chunk = on_chunk
        self._stop_event = threading.Event()
        self._done_event = threading.Event()
        #: Extra work :meth:`wait` does once the worker drains, so
        #: :meth:`TextToSpeech.say_stream` can also wait out playback.
        self.drain_hook: Optional[Any] = None
        self._thread = threading.Thread(target=self._pump, daemon=True)
        self._thread.start()

    def wait(self, timeout: Optional[float] = None) -> bool:
        """Block until the worker has drained the stream."""
        drained = self._done_event.wait(timeout)
        if drained and self.drain_hook is not None:
            self.drain_hook()
        return drained

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread.is_alive() and self._thread is not threading.current_thread():
            self._thread.join(timeout=2.0)

    def _pump(self) -> None:
        while not self._stop_event.is_set():
            try:
                status, chunk = moonshine_tts_next_chunk(self._handle)
            except Exception:
                print("TextToSpeech: streaming worker failed:", file=sys.stderr)
                traceback.print_exc(file=sys.stderr)
                break
            # Cancelling from anywhere ends the worker, so a caller who barges
            # in with cancel_stream() alone does not leave it polling.
            if status in (MOONSHINE_TTS_END_OF_STREAM, MOONSHINE_TTS_CANCELLED):
                break
            if status == MOONSHINE_TTS_NEED_TEXT or chunk is None:
                self._stop_event.wait(timeout=0.005)
                continue
            samples, sample_rate, text, utterance_id, is_final = chunk
            try:
                self._on_chunk(
                    TtsChunk(
                        samples=samples,
                        sample_rate=sample_rate,
                        text=text,
                        utterance_id=utterance_id,
                        is_final=is_final,
                    )
                )
            except Exception:
                print("TextToSpeech: on_chunk callback raised:", file=sys.stderr)
                traceback.print_exc(file=sys.stderr)
        self._done_event.set()


class SpeechInProgress:
    """Handle on the reply :meth:`TextToSpeech.say_stream` is speaking.

    Only a way to wait for or stop that reply; the text still goes in through
    the synthesizer's own :meth:`TextToSpeech.push_text`.
    """

    def __init__(self, synthesizer: "TextToSpeech", pump: "_ChunkPump") -> None:
        self._synthesizer = synthesizer
        self._pump = pump

    def wait(self, timeout: Optional[float] = None) -> bool:
        """Block until everything pushed has been spoken."""
        return self._pump.wait(timeout)

    def stop(self) -> None:
        """Stop the reply and drop anything still queued."""
        self._pump.stop()
        self._synthesizer.cancel_stream()

    def __enter__(self) -> "SpeechInProgress":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self._pump.stop()


@dataclass
class _SayRequest:
    """Queued utterance for the background synthesis worker."""
    text: str
    speed: Optional[float]
    volume: Optional[float]
    device: Optional[Union[int, str]]
    options: Optional[Dict[str, Union[str, int, float, bool]]]


@dataclass
class _PlayItem:
    """Synthesized audio ready for the playback worker."""
    data: Any  # numpy float32 array
    sample_rate: int
    device: Optional[Union[int, str]]


@dataclass
class _BeepRequest:
    """Queued beep marker; routed through the say queue so it plays in
    the same order as any in-flight :meth:`TextToSpeech.say` calls
    rather than racing ahead on the play queue.

    ``kind`` selects which packaged WAV to play:

    * ``"error"`` – ``assets/error.wav``, played to signal a
      misrecognition or a rejected utterance.
    * ``"success"`` – ``assets/success.wav``, played to signal a
      recognized utterance, just before the TTS response.
    """
    device: Optional[Union[int, str]]
    kind: str = "error"


_SHUTDOWN_SENTINEL = object()

# How long the persistent output stream stays open after the last utterance.
# Long enough that a reply arriving sentence by sentence plays through one
# stream, short enough not to hold an exclusive ALSA device from an idle app.
_OUTPUT_STREAM_IDLE_SECONDS = 1.0

# Beep WAVs shipped with the package.  The bundled clips are short,
# pre-recorded cues that already include any lead-in / fade
# the recording artist wanted; the runner just decodes and plays them
# verbatim through the same pipeline as a synthesized utterance, so
# the same device-resolution / resampling / mute path applies.
_BEEP_ASSET_FILES: Dict[str, str] = {
    "success": "success.wav",
    "error": "error.wav",
}

# Cache of decoded beep waveforms keyed by ``kind``.  Each entry is a
# ``(samples_float32, sample_rate)`` pair — the WAVs ship at 48 kHz
# and the runner converts to numpy float32 mono once per process,
# so subsequent ``play_success`` / ``play_error`` calls only pay the
# queue-handoff cost.  ``load_wav_file`` mixes stereo down to mono
# automatically, which is exactly what the playback worker expects.
_BEEP_CACHE: Dict[str, Tuple[Any, int]] = {}


def _load_beep_samples(np: Any, kind: str) -> Tuple[Any, int]:
    """Return ``(samples_float32, sample_rate)`` for the named beep.

    Loaded lazily from the packaged ``assets/<kind>.wav`` file the first
    time it's requested and cached for the lifetime of the process.
    Raises :class:`ValueError` for unknown kinds and lets file errors
    from :func:`load_wav_file` propagate (so a missing asset is loud,
    not silent — the symptom otherwise would be the same "no beep"
    issue we just spent two iterations debugging).
    """
    cached = _BEEP_CACHE.get(kind)
    if cached is not None:
        return cached
    filename = _BEEP_ASSET_FILES.get(kind)
    if filename is None:
        raise ValueError(f"Unknown beep kind {kind!r}")
    # Imported lazily to keep ``moonshine_voice.tts`` import-light
    # for callers that never invoke ``play_success`` / ``play_error``.
    from moonshine_voice.utils import get_assets_path, load_wav_file

    path = get_assets_path() / filename
    samples_list, sr = load_wav_file(path)
    samples = np.asarray(samples_list, dtype=np.float32)
    cached = (samples, int(sr))
    _BEEP_CACHE[kind] = cached
    return cached


def _import_say_audio_deps():
    """Import numpy and sounddevice for `TextToSpeech.say`; raise MoonshineError if missing."""
    try:
        import numpy as np
        import sounddevice as sd
    except ImportError as e:
        raise MoonshineError(
            "TextToSpeech.say() requires numpy and sounddevice "
            "(e.g. `pip install numpy sounddevice`)."
        ) from e
    return np, sd


def _resolve_default_output_index(sd: Any) -> Optional[int]:
    """Return PortAudio's current default output device index, if any.

    Wraps ``sd.default.device`` because sounddevice exposes that as a
    custom ``_InputOutputPair`` NamedTuple, *not* a plain ``tuple`` /
    ``list``, so an ``isinstance(..., (tuple, list))`` check on it
    misses and the diagnostic flag would silently never light up.
    Falls back through several access patterns so a minor sounddevice
    API change can't suppress the "current default" annotation.
    """
    try:
        default_pair = sd.default.device
    except Exception:
        return None
    try:
        out_idx = default_pair[1]
    except (TypeError, IndexError):
        try:
            out_idx = getattr(default_pair, "output", None)
        except Exception:
            out_idx = None
        if out_idx is None:
            try:
                out_idx = int(default_pair)
            except (TypeError, ValueError):
                return None
    if out_idx is None or out_idx == -1:
        return None
    try:
        return int(out_idx)
    except (TypeError, ValueError):
        return None


def list_output_devices() -> List[str]:
    """Return human-readable output device descriptions for diagnostics.

    Each entry is formatted ``"[idx] name (hostapi: NAME)"`` so a
    caller can paste either the index or a substring of the name into
    :class:`TextToSpeech`'s ``output_device`` argument (or the
    ``--output-device`` flag of the CLI demo).  The first line of the
    returned list flags PortAudio's default output device — on
    Raspberry Pi this is often *not* the one with speakers attached
    (e.g. HDMI when the user has wired up the 3.5 mm jack), and a
    silent assistant with no errors in the logs is exactly the
    symptom of the wrong device being selected.

    Use :class:`TextToSpeech`'s ``output_device`` to pin to a
    specific one when ``None`` (= host default) doesn't reach a
    speaker.
    """
    _, sd = _import_say_audio_deps()
    lines: List[str] = []
    default_out = _resolve_default_output_index(sd)
    try:
        hostapis = list(sd.query_hostapis())
    except Exception:
        hostapis = []
    try:
        devices = sd.query_devices()
    except Exception as e:
        return [f"<sounddevice query_devices() failed: {e!r}>"]
    for i, d in enumerate(devices):
        try:
            n_out = int(d.get("max_output_channels", 0) or 0)
        except (TypeError, ValueError):
            n_out = 0
        if n_out <= 0:
            continue
        name = str(d.get("name", "") or "")
        hostapi_idx = d.get("hostapi", -1)
        hostapi_name = ""
        try:
            hostapi_name = hostapis[hostapi_idx]["name"]
        except (IndexError, KeyError, TypeError):
            pass
        try:
            sr = int(d.get("default_samplerate", 0) or 0)
        except (TypeError, ValueError):
            sr = 0
        marker = "*" if i == default_out else " "
        lines.append(
            f"{marker} [{i}] {name} (hostapi: {hostapi_name or '?'}, "
            f"channels: {n_out}, default_sr: {sr or '?'} Hz)"
        )
    if not lines:
        lines.append("<no PortAudio output devices available>")
    return lines


def _say_enumerate_output_devices(sd) -> List[Tuple[int, str]]:
    """PortAudio device indices with at least one output channel, and host API name."""
    out: List[Tuple[int, str]] = []
    try:
        devices = sd.query_devices()
    except (sd.PortAudioError, OSError, ValueError) as e:
        raise MoonshineAudioOutputError(
            f"Could not query audio devices: {e}",
            available_outputs=[],
        ) from e
    for i, d in enumerate(devices):
        try:
            n_out = int(d.get("max_output_channels", 0) or 0)
        except (TypeError, ValueError):
            n_out = 0
        if n_out <= 0:
            continue
        name = str(d.get("name", "") or "")
        out.append((i, name))
    return out


def _say_device_lines(outs: List[Tuple[int, str]]) -> List[str]:
    return [f"[{i}] {name}" for i, name in outs]


def _say_device_spec_key(device: Optional[Union[int, str]]) -> Tuple[Any, ...]:
    if device is None:
        return ("default",)
    if isinstance(device, int):
        return ("idx", device)
    s = str(device).strip()
    if not s:
        return ("default",)
    try:
        return ("idx", int(s, 10))
    except ValueError:
        return ("name", s.casefold())


# Sample rates probed when the output device rejects the synthesizer's
# native rate. 48 kHz is the modern default and is a clean 2x integer
# upsample from the 24 kHz the C core emits, so we try it first. The rest
# are common consumer-audio rates; selection prefers integer multiples
# (or divisors) of the source rate and only falls back to the nearest
# rate when no clean ratio is available.
_RESAMPLE_CANDIDATES: Tuple[int, ...] = (
    48000, 96000, 192000, 44100, 88200, 32000, 22050, 16000, 11025, 8000,
)


def _select_output_sample_rate(
    sd: Any, *, device: Optional[int], source_sr: int,
) -> Tuple[Optional[int], Optional[Exception]]:
    """Pick the best output sample rate the device will actually open.

    Returns ``(target_sr, last_error)``. ``target_sr`` is ``None`` if no
    candidate rate works (in which case ``last_error`` is the PortAudio
    error from the source-rate probe and useful for diagnostics).
    Otherwise ``target_sr`` is:

    1. ``source_sr`` if the device accepts it natively (no resampling),
    2. 48000 Hz when supported (cleanest fallback for 24 kHz input),
    3. otherwise the largest supported rate that is an integer multiple
       or divisor of ``source_sr``,
    4. otherwise the supported rate closest to ``source_sr``.

    Probes that fail with ``paDeviceUnavailable`` (-9985) are retried
    a few times with a short backoff: that error code is transient on
    exclusive-access ALSA devices (e.g. USB DACs) when a previous
    ``sd.play()`` stream hasn't fully released the device yet, and a
    single failed probe shouldn't be enough to disqualify a rate the
    device actually supports.
    """
    last_err: Optional[Exception] = None

    def _try(sr: int) -> bool:
        nonlocal last_err
        # paDeviceUnavailable on Linux/ALSA after a just-finished play
        # commonly clears within ~10-50 ms; give it up to ~200 ms total
        # before believing the device really doesn't support this rate.
        for attempt in range(5):
            try:
                sd.check_output_settings(
                    samplerate=sr, channels=1, dtype="float32", device=device,
                )
                return True
            except sd.PortAudioError as e:
                last_err = e
                # PortAudioError stores the numeric code in ``args[1]``
                # for sounddevice; -9985 == paDeviceUnavailable.
                code = e.args[1] if len(e.args) >= 2 else None
                if code == -9985 and attempt < 4:
                    time.sleep(0.05)
                    continue
                return False
            except (OSError, ValueError) as e:
                last_err = e
                return False
        return False

    if _try(source_sr):
        return source_sr, None
    supported = [
        sr for sr in _RESAMPLE_CANDIDATES
        if sr != source_sr and _try(sr)
    ]
    if not supported:
        return None, last_err
    if 48000 in supported:
        return 48000, last_err
    multiples = [
        sr for sr in supported
        if sr % source_sr == 0 or source_sr % sr == 0
    ]
    if multiples:
        return max(multiples), last_err
    return min(supported, key=lambda sr: abs(sr - source_sr)), last_err


def _resample_linear(
    np: Any, samples: Any, source_sr: int, target_sr: int,
) -> Any:
    """Numpy-only linear-interpolation resample of mono float32 audio.

    Linear interpolation is the highest-quality resampler we can build
    without scipy; for clean integer ratios (e.g. 24 kHz -> 48 kHz) the
    new sample positions land exactly between source samples, so the
    interpolation error stays small.
    """
    if source_sr == target_sr or samples.size == 0:
        return samples.astype(np.float32, copy=False)
    n_src = int(samples.shape[0])
    n_dst = max(1, int(round(n_src * target_sr / source_sr)))
    if n_src == 1:
        return np.full(n_dst, float(samples[0]), dtype=np.float32)
    src_x = np.arange(n_src, dtype=np.float64)
    dst_x = np.linspace(0.0, n_src - 1, n_dst, dtype=np.float64)
    return np.interp(dst_x, src_x, samples).astype(np.float32)


def _normalize_clone_argument(
    clone: Union[str, Path, Tuple[Any, int]],
) -> Tuple[Any, int]:
    """Return ``(pcm, sample_rate)`` from a ``clone`` spec.

    Accepts either a path to a WAV file on disk (``str`` / ``Path``), which is
    decoded with :func:`moonshine_voice.utils.load_wav_file` (16/24-bit PCM,
    stereo mixed down to mono), or a ``(pcm, sample_rate)`` pair where ``pcm``
    is mono float PCM in ``[-1, 1]`` (any sequence or numpy array) and
    ``sample_rate`` is in Hz.
    """
    if isinstance(clone, (str, Path)):
        from moonshine_voice.utils import load_wav_file

        return load_wav_file(clone)
    if isinstance(clone, (tuple, list)) and len(clone) == 2:
        pcm, sample_rate = clone
        try:
            rate = int(sample_rate)
        except (TypeError, ValueError):
            rate = 0
        if rate > 0:
            return pcm, rate
    raise MoonshineError(
        "clone must be a path to a .wav file or a (pcm, sample_rate) pair "
        "(mono float PCM in [-1, 1] plus a positive sample rate in Hz)."
    )


def _say_resolve_output_index(
    spec_key: Tuple[Any, ...],
    outs: List[Tuple[int, str]],
    *,
    device_label_for_errors: str,
) -> Optional[int]:
    """Return PortAudio output device index, or None for the host default stream device."""
    lines = _say_device_lines(outs)
    if spec_key == ("default",):
        return None
    if spec_key[0] == "idx":
        idx = spec_key[1]
        valid = {i for i, _ in outs}
        if idx not in valid:
            raise MoonshineAudioOutputError(
                f"Output device index {idx} is not available or is not an output device.",
                available_outputs=lines,
            )
        return int(idx)
    needle = spec_key[1]
    for i, name in outs:
        if needle in name.casefold():
            return i
    raise MoonshineAudioOutputError(
        f"No output device name contains substring {device_label_for_errors!r} "
        "(match is case-insensitive substring).",
        available_outputs=lines,
    )


_OLD_CONSTRUCTOR_HELP = """\
TextToSpeech() no longer takes constructor arguments. Configure it with
chainable setters and call load():

    tts = TextToSpeech().language("en_us").voice("kokoro_af_heart")
    tts.load()
    tts.say("Hello from Moonshine.")

The old language argument is now .language(), asset_root is
.models_from(directory), and every other argument has a setter of the same
name (.voice(), .options(), .output_device(), .volume(), .debug()). Voice
cloning moved from the clone argument to .clone_from(source, transcript=...),
which you call after load()."""


class TextToSpeech:
    """Speaks text out loud, on device.

    Construct one, configure it with chainable setters, call :meth:`load` to
    fetch and open the voice, then :meth:`say`::

        tts = TextToSpeech().language("en_us").voice("kokoro_af_heart")
        tts.load()
        tts.say("Hello from Moonshine.")
        tts.wait()

    :meth:`load` blocks, since the first call may have to download assets; pass
    :meth:`on_progress` a handler to drive a progress bar. Use it as a context
    manager, or call :meth:`close` when you are done.

    Assets are resolved with ``moonshine_get_tts_dependencies`` and downloaded
    from ``https://download.moonshine.ai/tts/`` unless :meth:`models_from`
    points at a directory that already holds them. The language tag is
    validated against the native TTS catalog before anything is downloaded
    (`MoonshineTtsLanguageError` lists supported tags), and a voice is checked
    against the ones published for that language (`MoonshineTtsVoiceError`
    lists downloaded ids, then catalog ids available for download). Use
    `list_tts_languages` and `list_tts_voices` (``present`` /
    ``downloadable``), or `get_tts_voice_catalog`, to discover the options.

    Prefix a voice id with ``kokoro_``, ``piper_``, or ``zipvoice_`` to pin the
    vocoder (e.g. ``kokoro_af_heart``, ``zipvoice_american_female``). ZipVoice
    is a zero-shot voice cloner, so besides its built-in reference voices you
    can clone one of your own with :meth:`clone_from`.
    """

    # Voice id the native layer uses for a caller-supplied reference clip.
    _CLONE_VOICE = "zipvoice"
    # Built-in ZipVoice voice used by cloning() before a reference clip exists.
    _CLONE_PRESET_VOICE = "zipvoice_american_female"

    def __init__(self, *args, **kwargs):
        if args or kwargs:
            raise TypeError(_OLD_CONSTRUCTOR_HELP)

        # Deferred configuration, applied by load().
        self._language = "en"
        self._voice: Optional[str] = None
        self._extra_options: Dict[str, Union[str, int, float, bool]] = {}
        self._models_directory: Optional[Path] = None
        self._download = True
        self._cloning_wanted = False
        self._progress_fn: Optional[ProgressCallback] = None

        # Set up by load().
        self._lib: Any = None
        self._handle: Optional[int] = None
        self._asset_root: Optional[Path] = None

        # The reference clip the current voice was cloned from, if any.
        self._clone_samples: Optional[Any] = None
        self._clone_sample_rate = 0
        self._clone_transcript: Optional[str] = None
        # The native layer does not copy the reference PCM, so the buffer has
        # to outlive the synthesizer that was built from it.
        self._clone_pcm_buf: Any = None

        self._init_playback_state(None, None, False)

    # ------------------------------------------------------------ configuration

    def language(self, code: str) -> "TextToSpeech":
        """Synthesis language, e.g. ``"en"`` or ``"en_us"``. Defaults to ``"en"``."""
        self._language = code
        return self

    def voice(self, voice_id: str) -> "TextToSpeech":
        """Catalog voice id, e.g. ``"kokoro_af_heart"``. Clears :meth:`cloning`
        — a synthesizer is either a catalog voice or a cloning engine."""
        self._voice = voice_id
        self._cloning_wanted = False
        return self

    def models_from(
        self, directory: Union[str, Path], *, download: bool = False
    ) -> "TextToSpeech":
        """Load the voice assets from ``directory`` rather than the default cache.

        With ``download=False`` the directory has to be populated already. Pass
        ``download=True`` to use it as the cache root instead, fetching
        anything missing into it.
        """
        self._models_directory = Path(directory)
        self._download = bool(download)
        return self

    def cloning(self, enabled: bool = True) -> "TextToSpeech":
        """Create this synthesizer as a ZipVoice cloning engine.

        Call before :meth:`load` so ZipVoice and clone-ASR assets are fetched
        up front; afterwards :meth:`clone_from` does not download again.
        Clears :meth:`voice`. Only then may :meth:`clone_from` /
        :meth:`start_cloning` be used.
        """
        self._cloning_wanted = bool(enabled)
        if self._cloning_wanted:
            self._voice = None
        return self

    def on_progress(self, handler: ProgressCallback) -> "TextToSpeech":
        """Asset download progress, as a ``0..1`` fraction plus the file being fetched."""
        self._progress_fn = handler
        return self

    def options(
        self, options: Mapping[str, Union[str, int, float, bool]]
    ) -> "TextToSpeech":
        """Escape hatch for options the chainable setters don't cover."""
        self._extra_options.update(options)
        return self

    def output_device(self, device: Optional[Union[int, str]]) -> "TextToSpeech":
        """Playback device for :meth:`say`, as a PortAudio index or a name
        substring. Defaults to the system default output."""
        self._output_device = device
        return self

    def volume(self, volume: Optional[float]) -> "TextToSpeech":
        """Playback gain applied to everything :meth:`say` plays."""
        self._volume = volume
        return self

    def debug(self, enabled: bool = True) -> "TextToSpeech":
        """Trace synthesis and playback to stderr."""
        self._debug = bool(enabled)
        return self

    # ------------------------------------------------------------------ loading

    def load(self) -> "TextToSpeech":
        """Download the voice assets if needed and prepare the synthesizer.

        Blocking, since the first call may have to fetch a few hundred
        megabytes; report progress with :meth:`on_progress`. Calling it again
        is a no-op. With :meth:`cloning`, ZipVoice and clone ASR are both
        fetched here so :meth:`clone_from` stays offline afterward.
        """
        if self._handle is not None:
            return self
        if self._cloning_wanted and self._clone_samples is None:
            self._build(voice=self._CLONE_PRESET_VOICE)
            return self
        self._build(voice=self._voice)
        return self

    @property
    def language_tag(self) -> str:
        """The language tag this synthesizer was created with."""
        return self._language

    @property
    def asset_root(self) -> Path:
        if self._asset_root is None:
            raise MoonshineError("Call load() before reading asset_root.")
        return self._asset_root

    @property
    def is_cloned(self) -> bool:
        """True once a voice has been cloned into this synthesizer."""
        return self._clone_samples is not None

    # ----------------------------------------------------------------- cloning

    def clone_from(
        self,
        source: Union[str, Path, "VoiceClone", Tuple[Any, int]],
        *,
        transcript: Optional[str] = None,
    ) -> "TextToSpeech":
        """Clone the voice in ``source`` and use it for subsequent synthesis.

        Requires :meth:`cloning` before :meth:`load`. ``source`` may be a path
        to a ``.wav`` file, a ``(pcm, sample_rate)`` pair of mono float PCM, or
        a :class:`VoiceClone` that has captured enough speech.

        The clip is transcribed for the vocoder via assets already fetched by
        ``load`` when ``transcript`` is omitted.
        """
        self._require_cloning_mode("clone_from()")
        if self._handle is None:
            raise MoonshineError("Call load() before clone_from().")

        if isinstance(source, VoiceClone):
            audio = source.audio
            if audio is None:
                raise MoonshineError(
                    "That VoiceClone has not captured enough speech yet; "
                    "wait for on_ready."
                )
            pcm, sample_rate = audio, source.sample_rate
            if transcript is None and source.transcript:
                transcript = source.transcript
        else:
            pcm, sample_rate = _normalize_clone_argument(source)

        self._clone_samples = pcm
        self._clone_sample_rate = int(sample_rate)
        self._clone_transcript = (
            str(transcript).strip()
            if transcript is not None and str(transcript).strip()
            else None
        )
        self._build(voice=self._CLONE_VOICE)
        return self

    def start_cloning(
        self,
        *,
        clip_duration_seconds: float = 4.0,
        minimum_speech_seconds: float = 2.0,
    ) -> VoiceClone:
        """Start capturing a reference voice for cloning. Requires
        :meth:`cloning` before :meth:`load`."""
        self._require_cloning_mode("start_cloning()")
        handle = self._require_loaded("start_cloning()")
        return VoiceClone(
            tts_handle=handle,
            clip_duration_seconds=clip_duration_seconds,
            minimum_speech_seconds=minimum_speech_seconds,
        )

    # --------------------------------------------------------------- internals

    def _ensure_assets(self, *, voice: Optional[str]) -> Path:
        """Resolve the asset root, validating and downloading as needed."""
        # A bare "zipvoice" names the cloning engine rather than a catalog
        # voice, so the per-voice catalog checks below do not apply to it. Its
        # model files come down with the rest of the language's assets.
        catalog_voice = voice if voice != self._CLONE_VOICE else None
        if voice == self._CLONE_VOICE:
            self._language = normalize_moonshine_language_tag(self._language)

        if self._models_directory is not None and not self._download:
            root = Path(self._models_directory).resolve()
            if catalog_voice is not None or voice is None:
                self._language = validate_tts_language(
                    self._language,
                    voice=catalog_voice,
                    options=self._extra_options,
                    root_path=root,
                )
            if catalog_voice is not None:
                validate_tts_voice_known(
                    self._language,
                    catalog_voice,
                    options=self._extra_options,
                    root_path=root,
                )
            return root

        cache_root = (
            Path(self._models_directory) if self._models_directory is not None else None
        )
        validate_root = tts_asset_cache_path(cache_root)
        if catalog_voice is not None or voice is None:
            self._language = validate_tts_language(
                self._language,
                voice=catalog_voice,
                options=self._extra_options,
                root_path=validate_root,
            )
        if catalog_voice is not None:
            validate_tts_voice_known(
                self._language,
                catalog_voice,
                options=self._extra_options,
                root_path=validate_root,
            )
        root = download_tts_assets(
            self._language,
            voice=voice,
            options=self._extra_options,
            cache_root=cache_root,
            on_progress=self._progress_fn,
        )
        if catalog_voice is not None:
            ensure_tts_voice_downloaded(
                self._language,
                catalog_voice,
                root,
                options=self._extra_options,
                download_missing=True,
                show_progress=self._progress_fn is None,
                on_progress=self._progress_fn,
            )
        return root

    def _build(self, *, voice: Optional[str]) -> None:
        """Create the native synthesizer, replacing any earlier one."""
        # A voice named through options() rather than voice() still has to be
        # kept out of the catalog lookups below, which would otherwise be
        # biased by a voice we are still validating, and out of dependency
        # resolution, which would silently request a non-existent voice file.
        if voice is None:
            option_voice = self._extra_options.get("voice")
            if isinstance(option_voice, str) and option_voice.strip():
                voice = option_voice.strip()
        self._extra_options.pop("voice", None)
        if voice is not None:
            voice = str(voice).strip() or None
        if self._clone_samples is None:
            self._voice = voice

        self._asset_root = self._ensure_assets(voice=voice)
        self._lib = _MoonshineLib().lib
        if self._clone_samples is not None:
            handle = self._create_from_clone(voice=voice)
        else:
            handle = self._create_from_files(voice=voice)
        if handle < 0:
            msg = self._lib.moonshine_error_to_string(handle)
            raise MoonshineError(
                msg.decode("utf-8")
                if msg
                else f"Failed to create TTS synthesizer ({handle})"
            )
        previous = self._handle
        self._handle = handle
        if previous is not None:
            self._lib.moonshine_free_tts_synthesizer(previous)

    def _create_from_files(self, *, voice: Optional[str]) -> int:
        create_opts = self._c_options_for_create(voice)
        opt_arr, opt_n, _keep = moonshine_options_array(create_opts)
        return self._lib.moonshine_create_tts_synthesizer_from_files(
            self._language.encode("utf-8"),
            None,
            0,
            opt_arr,
            opt_n,
            MOONSHINE_HEADER_VERSION,
        )

    def _init_playback_state(
        self,
        output_device: Optional[Union[int, str]],
        volume: Optional[float],
        debug: bool,
    ) -> None:
        """Shared playback/queue state used by both the from-files and ZipVoice-from-memory paths."""
        self._closed = False
        self._say_device_cache: Optional[Tuple[Tuple[Any, ...],
                                               Optional[int]]] = None
        # ((spec_key, source_sr), target_sr) — target_sr equals source_sr
        # when the device accepts the synthesizer rate natively; otherwise
        # it's the resample target chosen by _select_output_sample_rate.
        self._say_settings_ok: Optional[Tuple[Tuple[Tuple[Any, ...], int], int]] = None

        # Kept open across queued utterances so a multi-sentence reply plays as
        # one continuous piece; see _acquire_output_stream.
        self._output_stream: Any = None
        self._output_stream_key: Optional[Tuple[Optional[int], int]] = None
        # When the audio handed to PortAudio should have finished coming out of
        # the speaker. Everything written is buffered, so this is what
        # ``is_talking`` and ``wait`` go by.
        self._playback_tail_until: float = 0.0

        self._say_queue: queue.Queue = queue.Queue()
        self._play_queue: queue.Queue = queue.Queue(maxsize=1)
        self._say_stop_event = threading.Event()
        self._synth_thread: Optional[threading.Thread] = None
        self._play_thread: Optional[threading.Thread] = None
        self._say_lock = threading.Lock()
        self._output_device = output_device
        self._volume = volume
        self._debug = bool(debug)
        self._log_start: Optional[float] = None
        self._log_last: Optional[float] = None
        self._log_lock = threading.Lock()
        # Set on the first `_play_one` call to a one-line summary of which PortAudio device the runner
        # actually opened. Only logged when ``debug=True`` (helps diagnose a silent setup with no
        # errors in the logs, often a wrong-default-device problem on Raspberry Pi).
        self._announced_resolved_device = False

    def _create_from_clone(self, *, voice: Optional[str]) -> int:
        """Create a ZipVoice synthesizer from the in-memory reference clip."""
        import array as _array

        # Coerce the reference clip to little-endian float32 bytes.
        try:
            import numpy as _np  # type: ignore
            pcm = _np.asarray(self._clone_samples, dtype="<f4").ravel()
            pcm_bytes = pcm.tobytes()
        except Exception:
            arr = _array.array("f", [float(x) for x in self._clone_samples])
            pcm = None
            pcm_bytes = arr.tobytes()

        if self._clone_transcript is None:
            print(
                "TextToSpeech: auto-transcribing clone reference clip with "
                "owned ZipVoice ASR...",
                file=sys.stderr,
                flush=True,
            )

        create_opts = self._c_options_for_create(voice or self._CLONE_VOICE)
        create_opts["zipvoice_clone_sample_rate"] = int(self._clone_sample_rate)
        if self._clone_transcript is not None:
            create_opts["zipvoice_clone_transcript"] = self._clone_transcript
        opt_arr, opt_n, _keep_opts = moonshine_options_array(create_opts)

        filenames = (ctypes.c_char_p * 1)(b"zipvoice/clone_audio")
        buf = (ctypes.c_uint8 * len(pcm_bytes)).from_buffer_copy(pcm_bytes)
        self._clone_pcm_buf = buf  # keep alive for the synthesizer's lifetime
        mem_ptrs = (ctypes.POINTER(ctypes.c_uint8) * 1)(
            ctypes.cast(buf, ctypes.POINTER(ctypes.c_uint8))
        )
        mem_sizes = (ctypes.c_uint64 * 1)(len(pcm_bytes))

        return self._lib.moonshine_create_tts_synthesizer_from_memory(
            self._language.encode("utf-8"),
            filenames,
            1,
            mem_ptrs,
            mem_sizes,
            opt_arr,
            opt_n,
            MOONSHINE_HEADER_VERSION,
        )

    def _announce_resolved_device(self, sd: Any, resolved: Optional[int]) -> None:
        """Print a one-liner identifying the PortAudio device we opened.

        Emitted only when ``debug=True`` (silent during normal use). When enabled
        it helps diagnose a silent runtime with no errors in the trace, which is
        almost always the *wrong* PortAudio device being selected (e.g. HDMI on a
        Pi when speakers are on the 3.5 mm jack); the log shows *which* device the
        worker actually opened.

        Includes the host-API name and the default sample rate the
        device claims to support; on top of that, when the resolved
        device is the host default we list the other available
        outputs so the user can pin a specific one via
        ``TextToSpeech(output_device=...)`` (or the CLI's
        ``--output-device`` flag).

        Only emitted when ``debug=True``; it is silent during normal use.
        """
        if not self._debug:
            return
        try:
            if resolved is None:
                idx = _resolve_default_output_index(sd)
                origin = "host default"
            else:
                idx = resolved
                origin = "explicit"
            info = sd.query_devices(idx) if idx is not None else None
            try:
                hostapis = list(sd.query_hostapis())
            except Exception:
                hostapis = []
            hostapi_name = ""
            if info is not None:
                try:
                    hostapi_name = hostapis[info.get("hostapi", -1)]["name"]
                except (IndexError, KeyError, TypeError):
                    pass
            name = info.get("name", "?") if info else "?"
            default_sr = info.get("default_samplerate", "?") if info else "?"
            print(
                f"TextToSpeech: opening PortAudio output [{idx}] {name!r} "
                f"({origin}, hostapi: {hostapi_name or '?'}, "
                f"default_sr: {default_sr} Hz). "
                f"If you don't hear anything, this may be the wrong "
                f"device — list alternatives with "
                f"`moonshine_voice.tts.list_output_devices()` and pin "
                f"one via `TextToSpeech(output_device=...)`.",
                file=sys.stderr,
                flush=True,
            )
        except Exception as e:
            print(
                f"TextToSpeech: could not introspect resolved output "
                f"device (resolved={resolved!r}): {e!r}",
                file=sys.stderr,
                flush=True,
            )

    def _log(self, msg: str) -> None:
        """Emit a timestamped trace line to stderr when ``debug=True``.

        Same shape as ``AgentFlow._log`` so traces from the two
        components can be read together: each line shows the wall
        time since the previous log line and since the first log
        line of this instance.  Off by default — TTS traces are
        verbose and only useful for diagnosing playback problems
        (e.g. why a beep didn't seem to play).
        """
        if not self._debug:
            return
        with self._log_lock:
            now = time.perf_counter()
            if self._log_start is None:
                self._log_start = now
                self._log_last = now
            delta_ms = (now - (self._log_last or now)) * 1000.0
            total_ms = (now - (self._log_start or now)) * 1000.0
            self._log_last = now
            print(
                f"[TextToSpeech +{delta_ms:7.1f}ms / {total_ms:8.1f}ms] {msg}",
                file=sys.stderr,
                flush=True,
            )

    def _c_options_for_create(
        self, voice: Optional[str]
    ) -> Dict[str, Union[str, int, float, bool]]:
        merged: Dict[str, Union[str, int, float, bool]] = dict(
            self._extra_options)
        merged["g2p_root"] = str(self._asset_root)
        if voice is not None:
            merged["voice"] = voice
        return merged

    def _require_loaded(self, what: str) -> int:
        if self._handle is None:
            raise MoonshineError(f"Call load() before {what}.")
        return self._handle

    def _require_cloning_mode(self, what: str) -> None:
        if not self._cloning_wanted:
            raise MoonshineError(
                f"Call cloning() before load() to use {what}. "
                "Catalog voices and cloning are separate synthesizer modes."
            )

    def synthesize(
        self,
        text: str,
        *,
        speed: Optional[float] = None,
        volume: Optional[float] = None,
        options: Optional[Dict[str, Union[str, int, float, bool]]] = None,
    ) -> Tuple[List[float], int]:
        """Synthesize ``text`` to PCM float samples ``(-1..1)`` and sample rate in Hz."""

        if options is None:
            options = {}

        if speed is not None:
            options["speed"] = str(speed)

        if volume is not None:
            options["output_volume"] = str(volume)

        handle = self._require_loaded("synthesize()")
        return moonshine_text_to_speech_samples(handle, text, options)

    def synthesize_from_phonemes(
        self,
        phonemes: str,
        *,
        speed: Optional[float] = None,
        volume: Optional[float] = None,
        options: Optional[Dict[str, Union[str, int, float, bool]]] = None,
    ) -> Tuple[List[float], int]:
        """Synthesize speech directly from IPA ``phonemes``, skipping grapheme-to-phoneme conversion.

        ``phonemes`` is an International Phonetic Alphabet string in the same format produced by
        :meth:`~moonshine_voice.g2p.GraphemeToPhonemizer.to_ipa`. Passing the raw
        phonemes for the same language yields audio equivalent to :meth:`synthesize` on the original
        text, but lets you inspect or edit the phonemes in between (e.g. to fix a name's
        pronunciation). Returns PCM float samples ``(-1..1)`` and the sample rate in Hz.
        """
        if options is None:
            options = {}

        if speed is not None:
            options["speed"] = str(speed)

        if volume is not None:
            options["output_volume"] = str(volume)

        handle = self._require_loaded("synthesize_from_phonemes()")
        return moonshine_phonemes_to_speech_samples(handle, phonemes, options)

    # ---------------------------------------------------------------- streaming
    #
    # Text goes in as it is written and audio comes out in pieces, so the first
    # clause of a reply can play while the rest is still being generated. For
    # text you already have in full, :meth:`say` and :meth:`synthesize` are
    # simpler.
    #
    # A synthesizer speaks one thing at a time: :meth:`push_text` starts a
    # generation, :meth:`end_input` finishes it, :meth:`cancel_stream` abandons
    # it, and :meth:`synthesize` raises while one is in flight. There is no
    # session object to create or close.

    def push_text(self, text: str) -> None:
        """Append text to the reply being spoken, starting one if needed.

        Pieces are concatenated verbatim, so feeding an LLM's output token by
        token reassembles the words correctly. Text is held back until it forms
        a complete sentence, because synthesizing half a clause gets the
        prosody wrong.
        """
        if not text:
            return
        handle = self._require_loaded("push_text()")
        moonshine_tts_push_text(handle, text)

    def flush(self) -> None:
        """Queue the buffered fragment even though it has no terminator."""
        moonshine_tts_flush(self._require_loaded("flush()"))

    def end_input(self) -> None:
        """Declare that no more text is coming, letting the reply finish."""
        moonshine_tts_end_input(self._require_loaded("end_input()"))

    def cancel_stream(self) -> None:
        """Drop queued text and abandon the reply in progress.

        This is the barge-in path: when someone interrupts the assistant, stop
        the reply.
        """
        moonshine_tts_cancel(self._require_loaded("cancel_stream()"))

    @property
    def is_streaming(self) -> bool:
        """Whether a reply is part-spoken."""
        if self._handle is None:
            return False
        return moonshine_tts_is_streaming(self._handle)

    def next_chunk(self) -> Optional[TtsChunk]:
        """Synthesize and return the next chunk on the calling thread.

        Returns ``None`` when no complete sentence is buffered yet, when input
        has ended and everything queued has been spoken, or when a cancel
        discarded the reply. Use :meth:`stream` to tell those apart.
        """
        handle = self._require_loaded("next_chunk()")
        status, chunk = moonshine_tts_next_chunk(handle)
        if status != 0 or chunk is None:
            return None
        samples, sample_rate, text, utterance_id, is_final = chunk
        return TtsChunk(
            samples=samples,
            sample_rate=sample_rate,
            text=text,
            utterance_id=utterance_id,
            is_final=is_final,
        )

    def stream(self, text: Optional[Union[str, Iterable[str]]] = None) -> Iterator[TtsChunk]:
        """Iterate the chunks of a reply, synthesizing on the calling thread::

            for chunk in tts.stream(llm_reply_tokens()):
                play(chunk.samples)

        With ``text``, that whole reply is pushed and ended for you: pass a
        string, or an iterable of pieces to consume as they arrive. Without it,
        drive :meth:`push_text` from another thread and iterate here.
        """
        if isinstance(text, str):
            self.push_text(text)
            self.end_input()
            text = None
        handle = self._require_loaded("stream()")
        pieces = iter(text) if text is not None else None
        while True:
            if pieces is not None:
                # Keep the synthesizer fed from the same thread that drains it,
                # so a generator of tokens needs no threading from the caller.
                try:
                    self.push_text(next(pieces))
                except StopIteration:
                    pieces = None
                    self.end_input()
            status, raw = moonshine_tts_next_chunk(handle)
            # A cancel from another thread ends the iteration even mid-reply,
            # and even while there is still text left to push.
            if status == MOONSHINE_TTS_CANCELLED:
                return
            if status == 0 and raw is not None:
                samples, sample_rate, chunk_text, utterance_id, is_final = raw
                yield TtsChunk(
                    samples=samples,
                    sample_rate=sample_rate,
                    text=chunk_text,
                    utterance_id=utterance_id,
                    is_final=is_final,
                )
            elif pieces is None and not self.is_streaming:
                return

    def say_stream(
        self,
        *,
        device: Optional[Union[int, str]] = None,
    ) -> SpeechInProgress:
        """Speak text that is still being written, a piece at a time.

        The streaming counterpart to :meth:`say`: push text as it arrives with
        :meth:`push_text` and each chunk plays as soon as it is synthesized,
        through the same persistent output stream, so a reply written token by
        token comes out as continuous speech.

            with tts.say_stream() as speech:
                for token in llm_reply():
                    tts.push_text(token)
                tts.end_input()
                speech.wait()

        :meth:`is_talking` and :meth:`wait` cover streamed audio too.
        """
        handle = self._require_loaded("say_stream()")
        np, _ = _import_say_audio_deps()
        if self._output_device is not None:
            device = self._output_device

        def enqueue(chunk: TtsChunk) -> None:
            if not chunk.samples:
                return
            self._play_queue.put(_PlayItem(
                data=np.asarray(chunk.samples, dtype=np.float32),
                sample_rate=int(chunk.sample_rate),
                device=device,
            ))

        self._ensure_say_workers()
        pump = _ChunkPump(self, handle, enqueue)
        pump.drain_hook = self.wait
        return SpeechInProgress(self, pump)

    def say(
        self,
        text: Union[str, List[str]],
        *,
        speed: Optional[float] = None,
        volume: Optional[float] = None,
        device: Optional[Union[int, str]] = None,
        options: Optional[Dict[str, Union[str, int, float, bool]]] = None,
    ) -> None:
        """
        Queue ``text`` for synthesis and playback, returning immediately.

        ``text`` may be a single string or a list of strings. A list is equivalent to calling
        ``say`` once per element in order. Long strings are split on an approximate
        sentence boundary (``.``, ``!``, or ``?`` followed by whitespace) so the first
        sentence can start playing while later ones synthesize.

        Utterances are played in order. Synthesis of the next utterance is pipelined with playback
        of the current one so there is minimal gap between consecutive utterances. Call `stop` to
        cancel all pending utterances and halt the currently-playing audio.

        Uses `synthesize` for audio generation; ``options`` is passed through unchanged.

        ``device`` may be ``None`` (host default output), a PortAudio device index, a decimal string
        index, or a substring of the device name (case-insensitive). If there are no output devices,
        the index is invalid, or no name matches, the error is raised on the calling thread before
        the utterance is enqueued.
        """
        self._require_loaded("say()")
        _import_say_audio_deps()

        if self._output_device is not None:
            device = self._output_device

        if self._volume is not None:
            volume = self._volume

        chunks = text if isinstance(text, list) else [text]
        for chunk in chunks:
            for sentence in split_say_utterances(chunk, self._language):
                self._say_queue.put(_SayRequest(
                    text=sentence,
                    speed=speed,
                    volume=volume,
                    device=device,
                    options=options,
                ))
        self._ensure_say_workers()

    def play_error(
        self,
        *,
        device: Optional[Union[int, str]] = None,
    ) -> None:
        """Play the bundled "error" beep and return immediately.

        Plays ``assets/error.wav`` queued through the same pipeline as
        :meth:`say` — so if a previous ``say`` hasn't finished speaking
        yet the beep plays right after it, rather than racing ahead.
        Use :meth:`wait` / :meth:`is_talking` to track playback.

        Pairs with :meth:`play_success`: callers that want audible
        feedback for whether speech recognition succeeded can call
        :meth:`play_success` on a recognized utterance and
        :meth:`play_error` on an unrecognized one.

        ``device`` accepts the same values as :meth:`say` (``None`` =
        constructor's ``output_device`` if set, otherwise host
        default; a PortAudio index, a decimal string index, or a
        case-insensitive device-name substring).  Honouring the
        constructor's ``output_device`` here matches :meth:`say`'s
        behaviour — without that, callers who pin a specific output
        device for speech would get their cue beeps routed to the
        host default and end up with audible speech but inaudible
        beeps.
        """
        _import_say_audio_deps()
        if device is None and self._output_device is not None:
            device = self._output_device
        self._log(f"play_error: enqueue (device={device!r})")
        self._say_queue.put(_BeepRequest(device=device, kind="error"))
        self._ensure_say_workers()

    def play_success(
        self,
        *,
        device: Optional[Union[int, str]] = None,
    ) -> None:
        """Play the bundled "success" beep and return immediately.

        Counterpart to :meth:`play_error` for positive feedback: plays
        ``assets/success.wav`` confirming that the most recent
        utterance was recognized / accepted.  Same queueing rules as
        :meth:`play_error` — decoded once, cached, and ordered
        through the say queue so it never races ahead of an in-flight
        :meth:`say`.

        ``device`` accepts the same values as :meth:`say` and falls
        back to the constructor's ``output_device`` when ``None``,
        for the same reason as :meth:`play_error`.
        """
        _import_say_audio_deps()
        if device is None and self._output_device is not None:
            device = self._output_device
        self._log(f"play_success: enqueue (device={device!r})")
        self._say_queue.put(_BeepRequest(device=device, kind="success"))
        self._ensure_say_workers()

    def _ensure_say_workers(self) -> None:
        with self._say_lock:
            alive = (
                self._synth_thread is not None and self._synth_thread.is_alive()
                and self._play_thread is not None and self._play_thread.is_alive()
            )
            if alive:
                return
            self._say_stop_event.clear()
            st = threading.Thread(target=self._synth_worker, daemon=True)
            pt = threading.Thread(target=self._play_worker, daemon=True)
            st.start()
            pt.start()
            self._synth_thread = st
            self._play_thread = pt

    # -- synthesis thread ----------------------------------------------------

    def _synth_worker(self) -> None:
        np, _ = _import_say_audio_deps()

        while not self._say_stop_event.is_set():
            try:
                req = self._say_queue.get(timeout=0.1)
            except queue.Empty:
                continue

            if req is _SHUTDOWN_SENTINEL:
                self._say_queue.task_done()
                break

            if self._say_stop_event.is_set():
                self._say_queue.task_done()
                break

            try:
                if isinstance(req, _BeepRequest):
                    self._log(
                        f"synth_worker: dequeued beep kind={req.kind!r}"
                    )
                    samples, beep_sr = _load_beep_samples(np, req.kind)
                    item = _PlayItem(
                        data=samples,
                        sample_rate=beep_sr,
                        device=req.device,
                    )
                    self._log(
                        f"synth_worker: beep ready ({req.kind!r}, "
                        f"{len(item.data)} samples @ {item.sample_rate} Hz)"
                    )
                else:
                    self._log(
                        "synth_worker: dequeued say request"
                        f" (text={(req.text or '')[:40]!r})"
                    )
                    item = self._synthesize_one(req, np)
                    self._log(
                        f"synth_worker: synth done "
                        f"({len(item.data)} samples @ {item.sample_rate} Hz)"
                    )
                if not self._say_stop_event.is_set():
                    self._log("synth_worker: handing item to play_queue")
                    self._play_queue.put(item)
                    self._log("synth_worker: item accepted by play_queue")
            except Exception:
                print(
                    "TextToSpeech: synthesis worker dropped an utterance:",
                    file=sys.stderr,
                )
                traceback.print_exc(file=sys.stderr)
            finally:
                self._say_queue.task_done()

    def _synthesize_one(self, req: _SayRequest, np: Any) -> _PlayItem:
        """Synthesize a single utterance into a _PlayItem (runs on synthesis thread)."""
        samples, sr = self.synthesize(
            req.text, speed=req.speed, volume=req.volume, options=req.options)
        data = np.asarray(samples, dtype=np.float32)
        return _PlayItem(data=data, sample_rate=int(sr), device=req.device)

    # -- playback thread -----------------------------------------------------

    def _play_worker(self) -> None:
        np, sd = _import_say_audio_deps()

        idle_since: Optional[float] = None
        while not self._say_stop_event.is_set():
            try:
                item = self._play_queue.get(timeout=0.1)
            except queue.Empty:
                # Nothing queued: let the device go after a short grace period,
                # long enough that a reply arriving sentence by sentence still
                # plays through one stream.
                if self._output_stream is not None:
                    now = time.perf_counter()
                    if idle_since is None:
                        idle_since = now
                    elif now - idle_since >= _OUTPUT_STREAM_IDLE_SECONDS:
                        self._release_output_stream()
                        idle_since = None
                continue
            idle_since = None

            if item is _SHUTDOWN_SENTINEL:
                self._play_queue.task_done()
                break

            if self._say_stop_event.is_set():
                self._play_queue.task_done()
                break

            try:
                self._play_one(item, sd, np)
            except Exception:
                print(
                    "TextToSpeech: playback worker failed to play an utterance:",
                    file=sys.stderr,
                )
                traceback.print_exc(file=sys.stderr)
            finally:
                self._play_queue.task_done()
        self._release_output_stream(abort=self._say_stop_event.is_set())

    def _play_one(self, item: _PlayItem, sd: Any, np: Any) -> None:
        """Resolve the device and play a single synthesized utterance (runs on playback thread)."""
        spec_key = _say_device_spec_key(item.device)
        if isinstance(item.device, str):
            name_label = item.device.strip()
        elif item.device is not None:
            name_label = str(item.device)
        else:
            name_label = ""

        if self._say_device_cache is None or self._say_device_cache[0] != spec_key:
            outs = _say_enumerate_output_devices(sd)
            if not outs:
                raise MoonshineAudioOutputError(
                    "No audio output devices are available.",
                    available_outputs=[],
                )
            resolved = _say_resolve_output_index(
                spec_key,
                outs,
                device_label_for_errors=name_label or str(
                    item.device) if item.device is not None else "",
            )
            self._say_device_cache = (spec_key, resolved)
            self._say_settings_ok = None

        resolved = self._say_device_cache[1]

        if not self._announced_resolved_device:
            self._announced_resolved_device = True
            self._announce_resolved_device(sd, resolved)

        if self._say_stop_event.is_set():
            return

        settings_key = (spec_key, item.sample_rate)
        cached = self._say_settings_ok
        if cached is not None and cached[0] == settings_key:
            target_sr = cached[1]
        else:
            target_sr, last_err = _select_output_sample_rate(
                sd, device=resolved, source_sr=item.sample_rate,
            )
            if target_sr is None:
                outs = _say_enumerate_output_devices(sd)
                tried = ", ".join(
                    str(sr) for sr in (item.sample_rate,) + _RESAMPLE_CANDIDATES
                )
                err_suffix = f": {last_err}" if last_err is not None else ""
                raise MoonshineAudioOutputError(
                    f"Audio output {resolved!r} rejected every probed sample rate "
                    f"({tried} Hz) for mono float32{err_suffix}.",
                    available_outputs=_say_device_lines(outs),
                ) from last_err
            self._say_settings_ok = (settings_key, target_sr)
            if target_sr != item.sample_rate:
                print(
                    f"TextToSpeech: output device does not support "
                    f"{item.sample_rate} Hz; resampling to {target_sr} Hz.",
                    file=sys.stderr,
                )

        if self._say_stop_event.is_set():
            return

        if target_sr != item.sample_rate:
            data = _resample_linear(
                np, item.data, item.sample_rate, target_sr)
        else:
            data = item.data

        expected_duration_s = (len(data) / float(target_sr)) if target_sr else 0.0
        self._log(
            f"play_one: writing to output stream "
            f"({len(data)} samples @ {target_sr} Hz, "
            f"~{expected_duration_s * 1000.0:.1f} ms expected, "
            f"device={resolved!r})"
        )
        t_start = time.perf_counter()
        try:
            stream = self._acquire_output_stream(sd, resolved, target_sr)
            # ``write`` blocks until PortAudio has taken the samples, which
            # keeps the queue paced without ever stopping the stream, so
            # consecutive utterances run together instead of being separated by
            # a device teardown and reopen.
            stream.write(data)
            try:
                self._playback_tail_until = time.perf_counter() + float(stream.latency)
            except Exception:  # pragma: no cover - backend without a latency
                self._playback_tail_until = time.perf_counter()
            if self._say_stop_event.is_set():
                self._release_output_stream(abort=True)
                self._playback_tail_until = 0.0
                self._log("play_one: stop_event set during write")
                return
            self._log(
                f"play_one: handed {len(data)} samples to the device in "
                f"{(time.perf_counter() - t_start) * 1000.0:.1f} ms"
            )
        except (sd.PortAudioError, OSError, ValueError) as e:
            self._release_output_stream(abort=True)
            outs = _say_enumerate_output_devices(sd)
            raise MoonshineAudioOutputError(
                f"Failed to play audio: {e}",
                available_outputs=_say_device_lines(outs),
            ) from e

    def _acquire_output_stream(self, sd: Any, device: Optional[int], sample_rate: int) -> Any:
        """The open output stream for this device and rate, opening one if needed.

        Held open across utterances so a queued reply plays as one continuous
        piece of audio. It is closed once the queue goes idle
        (``_OUTPUT_STREAM_IDLE_SECONDS``) rather than kept forever, because on
        Linux/ALSA exclusive-access devices an open stream keeps the card
        claimed and everything else on the machine goes silent.
        """
        key = (device, sample_rate)
        if self._output_stream is not None and self._output_stream_key == key:
            return self._output_stream
        self._release_output_stream()
        stream = sd.OutputStream(
            samplerate=sample_rate,
            channels=1,
            dtype="float32",
            device=device,
        )
        stream.start()
        self._output_stream = stream
        self._output_stream_key = key
        self._log(f"acquire_output_stream: opened {device!r} @ {sample_rate} Hz")
        return stream

    def _release_output_stream(self, *, abort: bool = False) -> None:
        """Close the persistent output stream, dropping buffered audio if ``abort``."""
        stream = self._output_stream
        self._output_stream = None
        self._output_stream_key = None
        if stream is None:
            return
        try:
            if abort:
                stream.abort(ignore_errors=True)
            else:
                stream.stop(ignore_errors=True)
            stream.close(ignore_errors=True)
            self._log(f"release_output_stream: closed (abort={abort})")
        except Exception as err:  # pragma: no cover - defensive
            self._log(f"release_output_stream: close raised: {err!r}")

    def is_talking(self) -> bool:
        """Return ``True`` if utterances are queued, being synthesized, or currently playing."""
        if not self._say_queue.empty() or not self._play_queue.empty():
            return True
        # ``write`` returns once PortAudio has taken the samples, with up to a
        # buffer's worth still to come out of the speaker. The stream itself
        # stays open and active between utterances, so it cannot answer this.
        return time.perf_counter() < self._playback_tail_until

    def wait(self) -> None:
        """Block until all queued utterances have been synthesized and played."""
        self._say_queue.join()
        self._play_queue.join()
        remaining = self._playback_tail_until - time.perf_counter()
        if remaining > 0:
            time.sleep(remaining)

    def stop(self) -> None:
        """Clear the utterance queue and stop any audio currently playing.

        Returns once all pending utterances are discarded and the active playback (if any) has
        been halted. It is safe to call `say` again afterwards.
        """
        self._say_stop_event.set()

        for q in (self._say_queue, self._play_queue):
            while True:
                try:
                    q.get_nowait()
                    q.task_done()
                except queue.Empty:
                    break

        self._release_output_stream(abort=True)
        self._playback_tail_until = 0.0

        for thread in (self._synth_thread, self._play_thread):
            if thread is not None and thread.is_alive():
                thread.join(timeout=2.0)
        self._synth_thread = None
        self._play_thread = None

    def close(self) -> None:
        if getattr(self, "_closed", False):
            return
        self._closed = True
        if getattr(self, "_say_queue", None) is not None:
            self._say_stop_event.set()

            for q in (self._say_queue, self._play_queue):
                while True:
                    try:
                        q.get_nowait()
                        q.task_done()
                    except queue.Empty:
                        break

            self._release_output_stream(abort=True)
            self._playback_tail_until = 0.0

            for thread in (self._synth_thread, self._play_thread):
                if thread is not None and thread.is_alive():
                    thread.join(timeout=2.0)
            self._synth_thread = None
            self._play_thread = None
        self._release_output_stream(abort=True)
        self._say_device_cache = None
        self._say_settings_ok = None
        if getattr(self, "_handle", None) is not None:
            self._lib.moonshine_free_tts_synthesizer(self._handle)
            self._handle = None

    def __enter__(self) -> "TextToSpeech":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass


def _parse_options_cli(pairs: List[str]) -> Dict[str, Union[str, int, float, bool]]:
    """Parse ``KEY=value`` pairs from repeated ``--options`` (values stay strings except booleans)."""
    out: Dict[str, Union[str, int, float, bool]] = {}
    for item in pairs:
        if "=" not in item:
            raise ValueError(
                f"Invalid --options entry {item!r}; expected KEY=value (use quotes if needed)"
            )
        key, _, value = item.partition("=")
        key = key.strip()
        if not key:
            raise ValueError(f"Invalid --options entry {item!r}; key is empty")
        v = value.strip()
        low = v.lower()
        if low == "true":
            out[key] = True
        elif low == "false":
            out[key] = False
        else:
            out[key] = v
    return out


def _write_wav_mono_pcm16(path: Path, samples: List[float], sample_rate_hz: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(path), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sample_rate_hz)
        frames = bytearray()
        for x in samples:
            if not isinstance(x, float):
                x = float(x)
            if x > 1.0:
                x = 1.0
            elif x < -1.0:
                x = -1.0
            pcm = int(round(x * 32767.0))
            if pcm > 32767:
                pcm = 32767
            elif pcm < -32768:
                pcm = -32768
            frames.extend(pcm.to_bytes(2, byteorder="little", signed=True))
        w.writeframes(bytes(frames))


if __name__ == "__main__":
    import argparse
    import sys

    parser = argparse.ArgumentParser(
        description="Synthesize speech with Moonshine TTS (downloads assets if needed)."
    )
    parser.add_argument(
        "--language",
        default="en_us",
        help="Language tag (e.g. en_us, de, fr) (default: %(default)s)",
    )
    parser.add_argument(
        "--voice",
        default=None,
        help="Voice id with kokoro_ or piper_ prefix (e.g. kokoro_af_heart)",
    )
    parser.add_argument(
        "--clone",
        default=None,
        type=Path,
        metavar="WAV_PATH",
        help="Clone the voice from a reference .wav clip using ZipVoice",
    )
    parser.add_argument(
        "--clone-transcript",
        default=None,
        metavar="TEXT",
        help="Transcript of the --clone reference clip (optional; auto-transcribed with Moonshine ASR when omitted)",
    )
    parser.add_argument(
        "--text",
        default="Hello world!",
        help="Text to speak (default: %(default)r)",
    )
    out_or_device = parser.add_mutually_exclusive_group()
    out_or_device.add_argument(
        "--out",
        default=None,
        type=Path,
        metavar="PATH",
        help="Write mono PCM16 WAV to PATH (omit to play on default output or fall back to out.wav)",
    )
    out_or_device.add_argument(
        "--device",
        default=None,
        metavar="INDEX_OR_NAME",
        help="sounddevice output device (index or name substring)",
    )
    parser.add_argument(
        "--asset-root",
        default=None,
        metavar="PATH",
        help="Path to the asset root directory (default: auto-detect)",
    )
    parser.add_argument(
        "--options",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="Extra moonshine_option_t entries; repeat for multiple (e.g. --options speed=1.1)",
    )
    args = parser.parse_args()

    cache_root = args.asset_root
    if args.asset_root is None:
        args.asset_root = tts_asset_cache_path(None)

    extra: Dict[str, Union[str, int, float, bool]] = {
        "g2p_root": str(args.asset_root)}
    if args.options:
        try:
            for k, v in _parse_options_cli(args.options).items():
                extra[k] = v
        except ValueError as e:
            print(e, file=sys.stderr)
            sys.exit(2)

    if args.clone_transcript is not None and args.clone is None:
        print("--clone-transcript requires --clone", file=sys.stderr)
        sys.exit(2)

    try:
        tts = TextToSpeech().language(args.language).options(extra)
        if cache_root is not None:
            tts.models_from(cache_root, download=True)
        if args.voice is not None:
            tts.voice(args.voice)
        if args.clone is not None:
            if args.voice is not None:
                print(
                    "--voice and --clone are mutually exclusive: the reference "
                    "clip defines the voice.",
                    file=sys.stderr,
                )
                sys.exit(2)
            tts.cloning()
        with tts:
            tts.load()
            if args.clone is not None:
                tts.clone_from(args.clone, transcript=args.clone_transcript)
            if args.out is not None:
                samples, sr = tts.synthesize(args.text, options=extra)
                _write_wav_mono_pcm16(args.out, samples, sr)
            else:
                dev = None
                if args.device is not None:
                    t = args.device.strip()
                    dev = t if t else None
                try:
                    tts.say(args.text, device=dev, options=extra)
                    tts.wait()
                except MoonshineError as play_err:
                    fallback_path = Path("out.wav")
                    print(
                        f"Audio playback failed ({play_err}); writing {fallback_path}",
                        file=sys.stderr,
                    )
                    samples, sr = tts.synthesize(args.text, options=extra)
                    _write_wav_mono_pcm16(fallback_path, samples, sr)
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        sys.exit(130)
    except MoonshineError as e:
        print(e, file=sys.stderr)
        sys.exit(1)
