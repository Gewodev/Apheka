import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { 
  Play, Pause, RotateCcw, Target, Zap, Clock, 
  CheckCircle, Trophy, BookOpen, Sparkles, Flame,
  MessageSquare, Plus, Send, Lightbulb,
  Brain, Link, Trash2, Star, ClipboardList
} from 'lucide-react';
import { useApp } from '../../store/AppContext';
import { format, subDays } from 'date-fns';
import { es } from 'date-fns/locale';
import toast from 'react-hot-toast';

function calculateStreak(weeklyStudyTime: Record<string, number>): number {
  let streak = 0;
  const today = new Date();
  for (let i = 0; i < 365; i++) {
    const d = subDays(today, i);
    const key = format(d, 'yyyy-MM-dd');
    if ((weeklyStudyTime[key] || 0) > 0) streak++;
    else break;
  }
  return streak;
}

const tips = [
  'Hidrátate — tu cerebro funciona mejor con agua.',
  'Apaga notificaciones para mantener el enfoque.',
  'Divide tareas grandes en bloques de 25 min.',
  'Respira hondo 3 veces antes de empezar.',
  'Recompénsate al cumplir cada meta.',
  'Revisa lo avanzado cada 4 ciclos.',
  'Menos multitarea = más profundidad.',
  'El descanso no es pérdida, es recarga.',
];

const repasoConcepts = [
  { titulo: 'Ley de Pareto', desc: 'El 80% de resultados viene del 20% del esfuerzo. Enfócate en lo esencial.' },
  { titulo: 'Técnica Feynman', desc: 'Si no puedes explicarlo simple, no lo entiendes bien. Enséñalo para aprenderlo.' },
  { titulo: 'Curva del Olvido', desc: 'Repasa 24h, 7d y 30d después para fijar el conocimiento.' },
  { titulo: 'Active Recall', desc: 'Recuperar información activamente es 2x más efectivo que releer.' },
  { titulo: 'Spaced Repetition', desc: 'Distribuye el repaso en el tiempo para máxima retención.' },
];

const maxTowerBlocks = 8;

export default function Estudio() {
  const { 
    tasks, sessionTime, isTimerActive, toggleTimer, resetTimer,
    activeTaskId, unlinkTaskFromTimer, settings, dailyStudyTime,
    pomodoroSessions, incrementPomodoroSessions, studySessions,
    addStudySession, isRest, setIsRest, addTask, weeklyStudyTime
  } = useApp();

  const [sessionType, setSessionType] = useState<'pomodoro' | 'chrono'>('pomodoro');
  const [cacheInput, setCacheInput] = useState('');
  const [cacheEntries, setCacheEntries] = useState<string[]>([]);
  const [showCompletion, setShowCompletion] = useState(false);
  const [nextGoal, setNextGoal] = useState('');
  const [tipIndex, setTipIndex] = useState(0);
  const [conceptIndex, setConceptIndex] = useState(0);
  const [owasClaimed, setOwasClaimed] = useState(false);
  const restStartRef = useRef(0);
  const hasTriggeredRef = useRef(false);
  const tipTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const activeTask = tasks.find(t => t.id === activeTaskId);
  const todayStr = format(new Date(), 'yyyy-MM-dd');
  const todayDate = format(new Date(), "d 'de' MMMM yyyy", { locale: es as any });

  const tasksCompletedToday = useMemo(() => 
    tasks.filter(t => t.completedAt && t.completedAt.startsWith(todayStr)).length,
    [tasks, todayStr]
  );
  const activeTasksCount = useMemo(() => 
    tasks.filter(t => t.status !== 'completado').length,
    [tasks]
  );
  const streak = useMemo(() => calculateStreak(weeklyStudyTime), [weeklyStudyTime]);

  const recentSessions = useMemo(() => 
    [...studySessions].sort((a, b) => new Date(b.startedAt).getTime() - new Date(a.startedAt).getTime()).slice(0, 5),
    [studySessions]
  );
  const totalRecent = useMemo(() => recentSessions.reduce((acc, s) => acc + s.duration, 0), [recentSessions]);

  const pomodoroGoal = settings.pomodoroGoal || 4;
  const pomodoroProgress = Math.min(pomodoroSessions, pomodoroGoal);
  const progressPercent = Math.round((pomodoroProgress / pomodoroGoal) * 100);

  const towerFilled = Math.min(pomodoroSessions, maxTowerBlocks);
  const isTowerComplete = towerFilled >= maxTowerBlocks;
  const owasToday = pomodoroSessions;

  useEffect(() => {
    tipTimerRef.current = setInterval(() => setTipIndex(prev => (prev + 1) % tips.length), 15000);
    return () => { if (tipTimerRef.current) clearInterval(tipTimerRef.current); };
  }, []);

  useEffect(() => {
    const ci = setInterval(() => setConceptIndex(prev => (prev + 1) % repasoConcepts.length), 12000);
    return () => clearInterval(ci);
  }, []);

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const todayLabel = todayDate.charAt(0).toUpperCase() + todayDate.slice(1);
  const restElapsed = isRest ? sessionTime - restStartRef.current : 0;
  const restTimeLeft = Math.max(0, settings.shortBreakTime - restElapsed);
  const displayTime = sessionType === 'pomodoro' ? Math.max(0, settings.pomodoroTime - sessionTime) : sessionTime;

  const progressPct = useMemo(() => {
    if (sessionType === 'chrono' || settings.pomodoroTime === 0) return 0;
    return Math.min(100, (sessionTime / settings.pomodoroTime) * 100);
  }, [sessionTime, settings.pomodoroTime, sessionType]);

  const restProgressPct = useMemo(() => {
    if (!isRest || settings.shortBreakTime === 0) return 0;
    return Math.min(100, (restElapsed / settings.shortBreakTime) * 100);
  }, [restElapsed, settings.shortBreakTime, isRest]);

  const currentProgress = isRest ? restProgressPct : progressPct;

  useEffect(() => {
    if (isTimerActive && !isRest && sessionTime >= settings.pomodoroTime && !hasTriggeredRef.current && sessionType === 'pomodoro') {
      hasTriggeredRef.current = true;
      setIsRest(true);
      restStartRef.current = sessionTime;
      incrementPomodoroSessions();
      setShowCompletion(true);
    }
    if (isRest || !isTimerActive || sessionType !== 'pomodoro') hasTriggeredRef.current = false;
  }, [sessionTime, isTimerActive, sessionType, isRest, settings.pomodoroTime]);

  useEffect(() => {
    if (isRest && restElapsed >= settings.shortBreakTime) {
      setIsRest(false);
      resetTimer();
      toast.success('Descanso completado');
    }
  }, [restElapsed, isRest, settings.shortBreakTime]);

  const handleReset = () => {
    if (sessionTime >= 600) {
      addStudySession({
        type: sessionType, startedAt: new Date(Date.now() - sessionTime * 1000).toISOString(),
        endedAt: new Date().toISOString(), duration: sessionTime,
        taskId: activeTaskId || undefined, courseId: undefined, pauseCount: 0,
      });
    }
    resetTimer();
  };

  const handleToggle = () => {
    toggleTimer();
    if (!isTimerActive) toast.success(isRest ? 'Descanso reanudado' : 'Sesión iniciada');
  };

  const handleTypeChange = (type: 'pomodoro' | 'chrono') => {
    if (isTimerActive && sessionTime >= 600) handleReset();
    else resetTimer();
    setSessionType(type);
    setIsRest(false);
  };

  const handleCacheSubmit = useCallback(() => {
    if (!cacheInput.trim()) return;
    setCacheEntries(prev => [cacheInput.trim(), ...prev]);
    setCacheInput('');
  }, [cacheInput]);

  const handleCacheDelete = useCallback((idx: number) => {
    setCacheEntries(prev => prev.filter((_, i) => i !== idx));
  }, []);

  const handleCacheToTask = useCallback((text: string) => {
    addTask({ title: text, course: 'General', courseColor: '#E11D48', priority: 'medium', urgent: false, important: false });
    toast.success('Nota convertida en tarea');
  }, [addTask]);

  const handleClaimOwas = useCallback(() => {
    setOwasClaimed(true);
    toast.success(`🎉 ¡${owasToday} Owas reclamadas! Torre del conocimiento completa.`);
  }, [owasToday]);

  const handleCloseCompletion = useCallback(() => {
    setShowCompletion(false);
    setNextGoal('');
    if (nextGoal.trim()) toast.success(`Meta: "${nextGoal.trim()}"`);
  }, [nextGoal]);

  const currentConcept = repasoConcepts[conceptIndex];
  const canWriteCache = isTimerActive && !isRest;
  const taskStudyTime = activeTask?.studyTime || 0;

  return (
    <div className="page-container" style={{ display: 'flex', flexDirection: 'column', height: '100%', overflow: 'hidden', gap: 16 }}>
      
      {/* ── TOP BAR ── */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexShrink: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ background: 'var(--bg-surface)', padding: 3, borderRadius: 14, display: 'flex', gap: 3, border: '1px solid var(--border-subtle)', boxShadow: '0 2px 8px rgba(0,0,0,0.15)' }}>
            <button onClick={() => handleTypeChange('pomodoro')} style={{ padding: '8px 22px', borderRadius: 11, background: sessionType === 'pomodoro' ? 'var(--accent)' : 'transparent', border: 'none', color: sessionType === 'pomodoro' ? '#fff' : 'var(--text-muted)', fontSize: 12, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 7, letterSpacing: '0.02em', transition: 'all 200ms', position: 'relative', overflow: 'hidden' }}>
              <Clock size={15} /> POMODORO
              {sessionType === 'pomodoro' && <div style={{ position: 'absolute', bottom: 0, left: '20%', right: '20%', height: 2, background: 'rgba(255,255,255,0.4)', borderRadius: 2 }} />}
            </button>
            <button onClick={() => handleTypeChange('chrono')} style={{ padding: '8px 22px', borderRadius: 11, background: sessionType === 'chrono' ? 'var(--accent)' : 'transparent', border: 'none', color: sessionType === 'chrono' ? '#fff' : 'var(--text-muted)', fontSize: 12, fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 7, letterSpacing: '0.02em', transition: 'all 200ms', position: 'relative', overflow: 'hidden' }}>
              <Zap size={15} /> CRONÓMETRO
              {sessionType === 'chrono' && <div style={{ position: 'absolute', bottom: 0, left: '20%', right: '20%', height: 2, background: 'rgba(255,255,255,0.4)', borderRadius: 2 }} />}
            </button>
          </div>

          {/* ── WATER PROGRESS BAR ── */}
          <div style={{
            width: 100, height: 24, borderRadius: 7,
            background: 'var(--bg-base)',
            border: '1px solid var(--border-subtle)',
            position: 'relative', overflow: 'hidden',
            flexShrink: 0,
          }}>
            <div style={{
              position: 'absolute', bottom: 0, left: 0, right: 0,
              height: `${Math.max(currentProgress, isTimerActive ? 2 : 0)}%`,
              transition: 'height 1s linear',
              background: isRest
                ? 'linear-gradient(180deg, color-mix(in srgb, var(--success) 60%, transparent), var(--success))'
                : 'linear-gradient(180deg, color-mix(in srgb, var(--accent) 60%, transparent), var(--accent))',
              borderRadius: '0 0 6px 6px',
            }}>
              <div style={{
                position: 'absolute', top: -4, left: '-15%', right: '-15%', height: 8,
                background: 'rgba(255,255,255,0.15)',
                borderRadius: '50%',
                animation: currentProgress > 0 && isTimerActive ? 'waterWave 3s ease-in-out infinite' : 'none',
              }} />
            </div>
          </div>

          {/* ── ACTIVE TASK BADGE (al lado de la barra de progreso) ── */}
          {activeTask && (
            <div style={{
              display: 'flex', alignItems: 'center', gap: 8,
              background: `linear-gradient(135deg, ${activeTask.courseColor}12, transparent)`,
              padding: '4px 10px 4px 8px', borderRadius: 8,
              border: `1px solid ${activeTask.courseColor}20`,
              maxWidth: 220, flexShrink: 0,
            }}>
              <div style={{ width: 3, height: 18, borderRadius: 2, background: activeTask.courseColor, flexShrink: 0 }} />
              <div style={{ minWidth: 0 }}>
                <div style={{ fontSize: 10, fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', color: 'var(--text-primary)' }}>
                  {activeTask.title}
                </div>
                <div style={{ fontSize: 8, color: activeTask.courseColor, fontWeight: 500 }}>
                  {Math.floor(taskStudyTime / 60)} min estudiando
                </div>
              </div>
              <button onClick={unlinkTaskFromTimer} aria-label="Desvincular tarea"
                style={{
                  fontSize: 8, color: 'var(--text-muted)', cursor: 'pointer',
                  padding: '2px 4px', borderRadius: 4, background: 'transparent',
                  border: 'none', opacity: 0.3, flexShrink: 0, lineHeight: 1,
                  transition: 'opacity 200ms',
                }}
                onMouseEnter={e => e.currentTarget.style.opacity = '0.7'}
                onMouseLeave={e => e.currentTarget.style.opacity = '0.3'}>
                ✕
              </button>
            </div>
          )}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ fontSize: 12, fontWeight: 500, color: 'var(--text-secondary)' }}>{todayLabel}</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'var(--bg-surface)', padding: '6px 14px', borderRadius: 10, border: '1px solid var(--border-subtle)' }}>
            <Trophy size={14} className="text-accent" />
            <span style={{ fontSize: 12, fontWeight: 600 }}>{pomodoroProgress}/{pomodoroGoal}</span>
            <div style={{ display: 'flex', gap: 3 }}>
              {Array.from({ length: pomodoroGoal }).map((_, i) => (
                <div key={i} style={{ width: 8, height: 8, borderRadius: 3, background: i < pomodoroProgress ? 'var(--accent)' : 'var(--border-subtle)', transition: 'all 300ms' }} />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* ── MAIN: 3 COLUMNS ── */}
      <div style={{ flex: 1, display: 'flex', gap: 16, overflow: 'hidden' }}>
        
        {/* ── COL 1: TIMER + TORRE ── */}
        <div style={{ width: 280, flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 12 }}>
          <div className="bento-card" style={{
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 24,
            padding: '32px 24px',
            background: 'linear-gradient(180deg, #0d0d12 0%, #14141e 100%)',
            boxShadow: '0 8px 32px rgba(0,0,0,0.4)',
            border: '1px solid rgba(255,255,255,0.05)',
          }}>
            {/* LED Digital Display */}
            <div className="led-container" style={{
              width: '100%',
              borderRadius: 20,
              padding: '36px 16px 24px',
              textAlign: 'center',
              background: '#050508',
              boxShadow: 'inset 0 0 80px rgba(0,0,0,0.8), 0 0 40px rgba(225,29,72,0.1)',
              border: '1px solid rgba(255,255,255,0.03)',
              position: 'relative',
              overflow: 'hidden',
            }}>
              {/* BIG 7-segment LED display */}
              {(() => {
                const raw = isRest ? formatTime(restTimeLeft) : formatTime(displayTime);
                const parts = raw.split(':');
                const onColor = isRest ? '#10B981' : '#FF1744';
                const dimColor = 'rgba(255,255,255,0.02)';
                return (
                  <div style={{
                    display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 2,
                    transform: 'scale(1.8)', transformOrigin: 'center center',
                    margin: '16px 0 24px',
                  }}>
                    <SevenSegDigit digit={parseInt(parts[0][0])} onColor={onColor} dimColor={dimColor} />
                    <SevenSegDigit digit={parseInt(parts[0][1])} onColor={onColor} dimColor={dimColor} />
                    <SevenSegColon onColor={onColor} blinking={isTimerActive} dimColor={dimColor} />
                    <SevenSegDigit digit={parseInt(parts[1][0])} onColor={onColor} dimColor={dimColor} />
                    <SevenSegDigit digit={parseInt(parts[1][1])} onColor={onColor} dimColor={dimColor} />
                  </div>
                );
              })()}

              {/* Status */}
              <div style={{
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 6,
                padding: '6px 16px', borderRadius: 20, background: 'rgba(255,255,255,0.03)',
                margin: '0 auto', width: 'max-content'
              }}>
                <div style={{
                  width: 6, height: 6, borderRadius: '50%',
                  background: isRest ? '#10B981' : 'var(--accent)',
                  boxShadow: isRest
                    ? '0 0 8px rgba(16,185,129,0.8)'
                    : '0 0 8px var(--accent-glow)',
                  animation: isTimerActive ? 'pulseGlow 2s infinite' : 'none',
                }} />
                <span style={{
                  fontSize: 10, fontWeight: 700, letterSpacing: '0.2em',
                  color: isRest ? '#10B981' : 'var(--accent)',
                  opacity: 0.8,
                  textTransform: 'uppercase',
                }}>
                  {isRest ? 'Descanso' : 'Enfoque'}
                </span>
              </div>

              {/* Thin progress bar */}
              <div style={{
                position: 'absolute', bottom: 0, left: 0, right: 0, height: 3,
                background: 'rgba(255,255,255,0.03)',
              }}>
                <div style={{
                  height: '100%',
                  width: `${currentProgress}%`,
                  background: isRest
                    ? 'linear-gradient(90deg, transparent, #10B981)'
                    : 'linear-gradient(90deg, transparent, var(--accent))',
                  transition: 'width 1s linear',
                  borderRadius: '0 2px 0 0',
                  boxShadow: isRest ? '0 0 10px rgba(16,185,129,0.5)' : '0 0 10px rgba(225,29,72,0.5)'
                }} />
              </div>
            </div>

            {/* Controls */}
            <div style={{ display: 'flex', gap: 20 }}>
              <button onClick={handleToggle}
                style={{
                  width: 64, height: 64, borderRadius: '50%',
                  background: isTimerActive ? 'rgba(255,255,255,0.05)' : 'var(--accent)',
                  border: isTimerActive ? '1px solid rgba(255,255,255,0.08)' : 'none',
                  color: '#fff',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  cursor: 'pointer',
                  boxShadow: isTimerActive
                    ? 'none'
                    : '0 8px 24px rgba(225,29,72,0.4)',
                  transition: 'all 200ms',
                }} className="hover-lift">
                {isTimerActive ? <Pause size={24} fill="currentColor" /> : <Play size={24} fill="currentColor" style={{ marginLeft: 4 }} />}
              </button>
              <button onClick={handleReset}
                style={{
                  width: 64, height: 64, borderRadius: '50%',
                  background: 'var(--bg-deep)',
                  border: '1px solid rgba(255,255,255,0.06)',
                  color: 'var(--text-muted)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  cursor: 'pointer',
                  transition: 'all 200ms',
                }} className="hover-lift">
                <RotateCcw size={20} />
              </button>
            </div>
          </div>

          <div className="bento-card" style={{ padding: '10px 14px', display: 'flex', alignItems: 'center', gap: 10 }}>
            <Lightbulb size={14} style={{ color: '#F59E0B', flexShrink: 0 }} />
            <div style={{ fontSize: 10, color: 'var(--text-tertiary)', lineHeight: 1.4 }}>{tips[tipIndex]}</div>
          </div>

          {/* ── BRICK WALL TOWER ── */}
          <div className="bento-card" style={{ padding: '12px 14px', flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column', gap: 6 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <BuildingIcon />
              <span style={{ fontSize: 10, fontWeight: 500, color: 'var(--text-tertiary)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>Torre del Día</span>
              <span style={{ marginLeft: 'auto', fontSize: 10, color: 'var(--accent)', fontWeight: 600 }}>{towerFilled}/{maxTowerBlocks}</span>
            </div>
            <div style={{
              flex: 1, display: 'flex', flexDirection: 'column-reverse',
              alignItems: 'center', justifyContent: 'center',
              padding: '6px',
              background: 'var(--bg-base)',
              borderRadius: 8,
              border: '1px solid var(--border-subtle)',
              minHeight: 140,
            }}>
              {Array.from({ length: maxTowerBlocks }).map((_, i) => {
                const filled = i < towerFilled;
                const isOddRow = Math.floor((maxTowerBlocks - 1 - i) / 2) % 2 === 0;
                const isFullRow = (maxTowerBlocks - 1 - i) % 2 === 0;
                const brickColor = filled
                  ? `linear-gradient(135deg, ${isFullRow ? 'var(--accent)' : 'color-mix(in srgb, var(--accent) 80%, #FFD700)'}, ${isFullRow ? 'color-mix(in srgb, var(--accent) 70%, #FFD700)' : 'var(--accent)'})`
                  : 'var(--bg-base)';
                return (
                  <div key={i} style={{
                    width: isFullRow ? '85%' : '70%',
                    height: 16,
                    marginLeft: isFullRow ? '0' : (isOddRow ? '8%' : '0'),
                    borderRadius: 3,
                    background: brickColor,
                    border: `1px solid ${filled ? 'rgba(255,255,255,0.1)' : 'var(--border-subtle)'}`,
                    opacity: filled ? 1 : 0.3,
                    transition: 'all 500ms cubic-bezier(0.16, 1, 0.3, 1)',
                    transitionDelay: filled ? `${i * 60}ms` : '0ms',
                    boxShadow: filled
                      ? `0 1px 2px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.15)`
                      : 'none',
                    position: 'relative',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}>
                    {/* Brick mortar lines */}
                    {filled && (
                      <>
                        <div style={{
                          position: 'absolute', top: 0, bottom: 0, left: '30%', width: 1,
                          background: 'rgba(0,0,0,0.2)',
                        }} />
                        <div style={{
                          position: 'absolute', top: 0, bottom: 0, left: '65%', width: 1,
                          background: 'rgba(0,0,0,0.2)',
                        }} />
                        {filled && i === towerFilled - 1 && (
                          <div style={{
                            position: 'absolute', inset: 0,
                            background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.25), transparent)',
                            animation: 'shimmer 1.5s infinite',
                          }} />
                        )}
                      </>
                    )}
                  </div>
                );
              })}
            </div>
            {isTowerComplete && (
              <div style={{
                textAlign: 'center', padding: '8px 0 4px',
                animation: 'fadeIn 500ms ease',
              }}>
                <div style={{
                  display: 'inline-flex', alignItems: 'center', gap: 6,
                  background: 'color-mix(in srgb, var(--accent) 12%, transparent)',
                  border: '1px solid color-mix(in srgb, var(--accent) 30%, transparent)',
                  borderRadius: 10, padding: '3px 12px 3px 8px',
                  marginBottom: 6,
                }}>
                  <OwaMascot size={22} />
                  <span style={{ fontSize: 10, fontWeight: 600, color: 'var(--accent)' }}>¡Torre Completa!</span>
                </div>
                {!owasClaimed && (
                  <button onClick={handleClaimOwas} className="btn-primary" style={{
                    padding: '4px 16px', height: 28, fontSize: 11, gap: 5,
                    display: 'inline-flex', alignItems: 'center',
                    boxShadow: '0 0 20px var(--accent-glow)',
                    animation: 'pulseGlow 2s infinite',
                  }}>
                    <Star size={12} fill="currentColor" /> Reclamar {owasToday} Owas
                  </button>
                )}
                {owasClaimed && (
                  <div style={{ fontSize: 10, color: 'var(--success)', fontWeight: 600 }}>
                    🎉 {owasToday} Owas reclamadas
                  </div>
                )}
              </div>
            )}
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 4, marginTop: 'auto' }}>
              <Trophy size={10} className="text-accent" />
              <span style={{ fontSize: 9, color: 'var(--text-tertiary)', fontWeight: 500 }}>{owasToday} owas hoy</span>
            </div>
          </div>

        </div>

        {/* ── COL 2: HERRAMIENTAS DE ESTUDIO ── */}
        <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 12 }}>
          
          {/* Repaso Rápido */}
          <div className="bento-card" style={{ padding: '14px 18px', background: 'linear-gradient(135deg, var(--bg-surface), color-mix(in srgb, #8B5CF6 6%, transparent))' }}>
            <div className="section-header" style={{ marginBottom: 10 }}>
              <Brain size={13} style={{ color: '#8B5CF6' }} />Repaso Rápido
              <span className="view-all">Cambia cada 12s</span>
            </div>
            <div style={{ padding: '10px 12px', background: 'var(--bg-base)', borderRadius: 8, border: '1px solid var(--border-subtle)' }}>
              <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 4, color: '#8B5CF6' }}>{currentConcept.titulo}</div>
              <div style={{ fontSize: 11, color: 'var(--text-secondary)', lineHeight: 1.5 }}>{currentConcept.desc}</div>
            </div>
          </div>

          {/* Todavía pensando... (placeholder) */}
          <div className="bento-card" style={{
            flex: 1, minHeight: 0,
            display: 'flex', flexDirection: 'column',
            alignItems: 'center', justifyContent: 'center',
            gap: 12,
            background: 'linear-gradient(135deg, var(--bg-surface), color-mix(in srgb, #8B5CF6 4%, transparent))',
          }}>
            <div style={{
              width: 48, height: 48, borderRadius: '50%',
              background: 'color-mix(in srgb, #8B5CF6 10%, transparent)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Brain size={24} style={{ color: '#8B5CF6', opacity: 0.5 }} />
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--text-tertiary)' }}>Todavía pensando...</div>
              <div style={{ fontSize: 10, color: 'var(--text-muted)', marginTop: 4, maxWidth: 220, lineHeight: 1.5 }}>
                Estoy diseñando algo útil para este espacio. Pronto habrá novedades aquí.
              </div>
            </div>
            <div style={{ display: 'flex', gap: 4 }}>
              {[0, 1, 2].map(i => (
                <div key={i} style={{
                  width: 6, height: 6, borderRadius: '50%',
                  background: 'var(--text-muted)', opacity: 0.3,
                  animation: i === 1 ? 'pulseGlow 1.5s infinite' : 'none',
                }} />
              ))}
            </div>
          </div>

        </div>

        {/* ── COL 3: PANEL DE CONTROL ── */}
        <div style={{ width: 290, flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 12, overflowY: 'auto' }}>
          
          {/* Resumen del Día */}
          <div className="bento-card" style={{ padding: '12px 16px' }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
              <div style={{ background: 'var(--bg-base)', borderRadius: 6, border: '1px solid var(--border-subtle)', padding: '8px', textAlign: 'center' }}>
                <div style={{ fontSize: 18, fontWeight: 600, color: 'var(--accent)', lineHeight: 1 }}>{Math.floor(dailyStudyTime / 60)}<span style={{ fontSize: 10, color: 'var(--text-tertiary)', fontWeight: 500 }}>h</span></div>
                <div style={{ fontSize: 8, fontWeight: 500, color: 'var(--text-tertiary)', textTransform: 'uppercase', letterSpacing: '0.04em', marginTop: 2 }}>Estudio</div>
              </div>
              <div style={{ background: 'var(--bg-base)', borderRadius: 6, border: '1px solid var(--border-subtle)', padding: '8px', textAlign: 'center' }}>
                <div style={{ fontSize: 18, fontWeight: 600, color: '#F59E0B', lineHeight: 1 }}>{activeTasksCount}</div>
                <div style={{ fontSize: 8, fontWeight: 500, color: 'var(--text-tertiary)', textTransform: 'uppercase', letterSpacing: '0.04em', marginTop: 2 }}>Activas</div>
              </div>
              <div style={{ background: 'var(--bg-base)', borderRadius: 6, border: '1px solid var(--border-subtle)', padding: '8px', textAlign: 'center' }}>
                <div style={{ fontSize: 18, fontWeight: 600, color: '#10B981', lineHeight: 1 }}>{streak}<span style={{ fontSize: 10, color: 'var(--text-tertiary)', fontWeight: 500 }}>d</span></div>
                <div style={{ fontSize: 8, fontWeight: 500, color: 'var(--text-tertiary)', textTransform: 'uppercase', letterSpacing: '0.04em', marginTop: 2 }}>Racha</div>
              </div>
            </div>
            <div style={{ display: 'flex', gap: 6, marginTop: 8, justifyContent: 'center' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 3, background: 'var(--bg-base)', padding: '3px 8px', borderRadius: 5, border: '1px solid var(--border-subtle)' }}>
                <CheckCircle size={8} className="text-accent" /> <span style={{ fontSize: 9, fontWeight: 500, color: 'var(--text-secondary)' }}>{tasksCompletedToday} hechas</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 3, background: 'var(--bg-base)', padding: '3px 8px', borderRadius: 5, border: '1px solid var(--border-subtle)' }}>
                <Flame size={8} style={{ color: '#F59E0B' }} /> <span style={{ fontSize: 9, fontWeight: 500, color: 'var(--text-secondary)' }}>{pomodoroSessions} sesiones</span>
              </div>
            </div>
          </div>

          {/* Caché Mental — solo input */}
          <div className="bento-card" style={{ padding: '12px 16px' }}>
            <div className="section-header" style={{ marginBottom: 8 }}>
              <MessageSquare size={13} className="text-accent" />Caché Mental
              {cacheEntries.length > 0 && (
                <span style={{ marginLeft: 'auto', fontSize: 9, fontWeight: 600, color: 'var(--accent)', padding: '2px 6px', borderRadius: 4, background: 'color-mix(in srgb, var(--accent) 10%, transparent)' }}>
                  {cacheEntries.length}
                </span>
              )}
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              <input type="text" value={cacheInput} onChange={e => setCacheInput(e.target.value)}
                placeholder={canWriteCache ? 'Escribe y pulsa Enter...' : 'Disponible solo durante enfoque'}
                disabled={!canWriteCache}
                className="input-base"
                style={{
                  flex: 1, fontSize: 11, padding: '6px 10px', height: 32,
                  opacity: canWriteCache ? 1 : 0.4,
                  cursor: canWriteCache ? 'text' : 'not-allowed',
                }}
                onKeyDown={e => { if (e.key === 'Enter' && canWriteCache) handleCacheSubmit(); }} />
              <button onClick={handleCacheSubmit}
                disabled={!canWriteCache || !cacheInput.trim()}
                className="btn-primary"
                style={{
                  height: 32, width: 32, padding: 0,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  cursor: canWriteCache && cacheInput.trim() ? 'pointer' : 'not-allowed',
                  opacity: canWriteCache && cacheInput.trim() ? 1 : 0.3,
                }}>
                <Send size={13} />
              </button>
            </div>
            {!canWriteCache && (
              <div style={{ marginTop: 6, textAlign: 'center', fontSize: 9, color: 'var(--text-muted)' }}>
                {cacheEntries.length > 0
                  ? `${cacheEntries.length} nota${cacheEntries.length !== 1 ? 's' : ''} guardada${cacheEntries.length !== 1 ? 's' : ''} — revisa al pausar`
                  : 'Las notas se habilitan durante el enfoque'}
              </div>
            )}
          </div>

          {/* Historial + Caché flotante */}
          <div className="bento-card" style={{ flex: 1, padding: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column', minHeight: 0 }}>
            <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--border-subtle)' }} className="section-header">
              <BookOpen size={13} className="text-accent" />Historial
              {recentSessions.length > 0 && (
                <span style={{ marginLeft: 'auto', fontSize: 10, color: 'var(--text-secondary)' }}>{Math.floor(totalRecent / 60)}h {totalRecent % 60}m</span>
              )}
            </div>
            <div style={{ flex: 1, overflowY: 'auto', padding: '10px 16px', display: 'flex', flexDirection: 'column', gap: 6 }}>
              {recentSessions.length > 0 ? recentSessions.map((s, i) => {
                const isPomo = s.type === 'pomodoro';
                return (
                  <div key={s.id || i} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '7px 10px', background: 'var(--bg-base)', borderRadius: 6, border: '1px solid var(--border-subtle)' }}>
                    <div style={{ width: 24, height: 24, borderRadius: 5, background: isPomo ? 'color-mix(in srgb, var(--accent) 12%, transparent)' : 'color-mix(in srgb, #3B82F6 12%, transparent)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      {isPomo ? <Clock size={11} className="text-accent" /> : <Zap size={11} style={{ color: '#3B82F6' }} />}
                    </div>
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <span style={{ fontSize: 11, fontWeight: 600 }}>{isPomo ? 'Pomo' : 'Crono'}</span>
                        <span style={{ fontSize: 10, fontWeight: 600, color: 'var(--accent)' }}>{Math.floor(s.duration / 60)}m</span>
                      </div>
                      <div style={{ fontSize: 9, color: 'var(--text-tertiary)' }}>{format(new Date(s.startedAt), 'HH:mm', { locale: es as any })}</div>
                    </div>
                  </div>
                );
              }) : (
                <div style={{ padding: '20px 0', textAlign: 'center', color: 'var(--text-muted)', fontSize: 10, display: 'flex', flexDirection: 'column', gap: 4 }}>
                  <Clock size={20} style={{ opacity: 0.2, margin: '0 auto' }} />
                  <span>Sin sesiones</span>
                </div>
              )}

              {/* ── Floating cache entries inside historial ── */}
              {!isTimerActive && cacheEntries.length > 0 && (
                <div style={{
                  marginTop: 8, paddingTop: 8,
                  borderTop: '1px solid var(--border-subtle)',
                  display: 'flex', flexDirection: 'column', gap: 4,
                  animation: 'fadeIn 400ms ease',
                }}>
                  <div style={{ fontSize: 9, fontWeight: 500, color: 'var(--text-tertiary)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>
                    Caché Mental ({cacheEntries.length})
                  </div>
                  {cacheEntries.map((entry, i) => (
                    <div key={i} style={{
                      display: 'flex', alignItems: 'center', gap: 6,
                      padding: '6px 10px',
                      background: 'var(--bg-surface)',
                      border: '1px solid var(--border-subtle)',
                      borderRadius: 8,
                      fontSize: 10,
                      color: 'var(--text-secondary)',
                    }}>
                      <span style={{ flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{entry}</span>
                      <button onClick={() => handleCacheToTask(entry)}
                        className="btn-ghost"
                        style={{ fontSize: 8, color: 'var(--accent)', cursor: 'pointer', padding: '2px 6px', opacity: 0.7, flexShrink: 0, borderRadius: 4, background: 'color-mix(in srgb, var(--accent) 8%, transparent)', display: 'flex', alignItems: 'center', gap: 3 }}
                        title="Convertir en tarea"><ClipboardList size={11} /> Tarea</button>
                      <button onClick={() => handleCacheDelete(i)}
                        className="btn-ghost"
                        style={{ fontSize: 8, color: 'var(--text-muted)', cursor: 'pointer', padding: '2px 4px', opacity: 0.4, flexShrink: 0, display: 'flex', alignItems: 'center' }}
                        title="Eliminar"><Trash2 size={11} /></button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

        </div>

      </div>

      {/* ── POMODORO COMPLETION DIALOG ── */}
      {showCompletion && (
        <div style={{ position: 'fixed', inset: 0, zIndex: 2000, display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'rgba(0,0,0,0.65)', backdropFilter: 'blur(10px)' }} onClick={() => setShowCompletion(false)}>
          <div className="bento-card" style={{ width: 420, maxHeight: '85vh', overflowY: 'auto', padding: 28 }} onClick={e => e.stopPropagation()}>
            <div style={{ textAlign: 'center', marginBottom: 24 }}>
              <div style={{ width: 52, height: 52, borderRadius: '50%', background: 'color-mix(in srgb, var(--accent) 15%, transparent)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 12px auto' }}>
                <Sparkles size={26} className="text-accent" />
              </div>
              <h2 style={{ fontSize: 20, fontWeight: 600 }}>¡Enfoque Completado!</h2>
              <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 4 }}>Descansa {Math.floor(settings.shortBreakTime / 60)} min.</p>
            </div>
            <div style={{ display: 'flex', justifyContent: 'center', gap: 4, marginBottom: 20 }}>
              {Array.from({ length: pomodoroGoal }).map((_, i) => (
                <div key={i} style={{ width: 28, height: 28, borderRadius: 6, background: i < pomodoroProgress ? 'var(--accent)' : 'var(--border-subtle)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 600, color: i < pomodoroProgress ? '#fff' : 'transparent' }}>
                  {i < pomodoroProgress ? '✓' : ''}
                </div>
              ))}
            </div>
            <div style={{ textAlign: 'center', marginBottom: 20, fontSize: 12, color: 'var(--text-secondary)' }}>
              {pomodoroProgress}/{pomodoroGoal} pomodoros · {progressPercent}% de la meta
            </div>
            {cacheEntries.length > 0 && (
              <div style={{ marginBottom: 20 }}>
                <div style={{ fontSize: 11, fontWeight: 500, color: 'var(--text-tertiary)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6 }}>
                  <MessageSquare size={13} className="text-accent" /> Notas de esta sesión
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                  {cacheEntries.slice(0, 3).map((entry, i) => (
                    <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 10px', background: 'var(--bg-base)', borderRadius: 6, border: '1px solid var(--border-subtle)' }}>
                      <span style={{ flex: 1, fontSize: 11, color: 'var(--text-secondary)' }}>{entry}</span>
                      <button onClick={() => handleCacheToTask(entry)} className="btn-ghost" style={{ fontSize: 10, color: 'var(--accent)', cursor: 'pointer', padding: '2px 6px', display: 'flex', alignItems: 'center', gap: 3 }}>
                        <Plus size={11} /> Tarea
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
            <div style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 11, fontWeight: 500, color: 'var(--text-tertiary)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6 }}>
                <Target size={13} className="text-accent" /> Meta para el próximo enfoque
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <input type="text" value={nextGoal} onChange={e => setNextGoal(e.target.value)} placeholder="¿Qué vas a trabajar?" className="input-base" style={{ flex: 1 }} />
                <button onClick={() => { toast.success(`Meta: "${nextGoal}"`); setNextGoal(''); }} disabled={!nextGoal.trim()} className="btn-primary" style={{ padding: '0 14px', display: 'flex', alignItems: 'center', gap: 6, cursor: nextGoal.trim() ? 'pointer' : 'not-allowed', opacity: nextGoal.trim() ? 1 : 0.5 }}>
                  <Send size={14} /> Fijar
                </button>
              </div>
            </div>
            <button onClick={handleCloseCompletion} className="btn-secondary" style={{ width: '100%', justifyContent: 'center', cursor: 'pointer' }}>Cerrar</button>
          </div>
        </div>
      )}

    </div>
  );
}

/* ── 7-Segment LED Display ── */
const SEG_PATTERNS: Record<number, boolean[]> = {
  0: [true,true,true,true,true,true,false], 1: [false,true,true,false,false,false,false],
  2: [true,true,false,true,true,false,true], 3: [true,true,true,true,false,false,true],
  4: [false,true,true,false,false,true,true], 5: [true,false,true,true,false,true,true],
  6: [true,false,true,true,true,true,true], 7: [true,true,true,false,false,false,false],
  8: [true,true,true,true,true,true,true], 9: [true,true,true,true,false,true,true],
};

const SEG_RECTS = [
  { x:5.5, y:2.5, w:19, h:4.5 },  { x:23, y:6, w:4.5, h:17 },
  { x:23, y:29, w:4.5, h:17 },    { x:5.5, y:45, w:19, h:4.5 },
  { x:2.5, y:29, w:4.5, h:17 },   { x:2.5, y:6, w:4.5, h:17 },
  { x:5.5, y:23.75, w:19, h:4.5 },
];

function SevenSegDigit({ digit, onColor, dimColor }: { digit: number; onColor: string; dimColor: string }) {
  const p = SEG_PATTERNS[digit] || SEG_PATTERNS[0];
  return (
    <svg width="30" height="52" viewBox="0 0 30 52" style={{ flexShrink: 0 }}>
      {SEG_RECTS.map((r, i) => (
        <rect key={i} x={r.x} y={r.y} width={r.w} height={r.h} rx={2.5}
          fill={p[i] ? onColor : dimColor}
          filter={p[i] ? `drop-shadow(0 0 4px ${onColor})` : 'none'}
          style={{ transition: 'fill 200ms' }} />
      ))}
    </svg>
  );
}

function SevenSegColon({ onColor, blinking, dimColor }: { onColor: string; blinking: boolean; dimColor: string }) {
  const b = blinking ? 'blink 1s step-end infinite' : 'none';
  return (
    <svg width="14" height="52" viewBox="0 0 14 52" style={{ flexShrink: 0 }}>
      <circle cx="7" cy="15" r="2.8" fill={onColor} filter={`drop-shadow(0 0 3px ${onColor})`} style={{ animation: b }} />
      <circle cx="7" cy="37" r="2.8" fill={onColor} filter={`drop-shadow(0 0 3px ${onColor})`} style={{ animation: b }} />
    </svg>
  );
}

function BuildingIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="4" y="2" width="16" height="20" rx="2" ry="2" />
      <path d="M9 22v-4h6v4" />
      <path d="M8 6h.01" /><path d="M16 6h.01" />
      <path d="M8 10h.01" /><path d="M16 10h.01" />
      <path d="M8 14h.01" /><path d="M16 14h.01" />
    </svg>
  );
}

function OwaMascot({ size = 36 }: { size?: number }) {
  const s = size;
  return (
    <div style={{
      width: s, height: s, borderRadius: '50%',
      background: 'linear-gradient(135deg, var(--accent), #FFD700)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      position: 'relative', flexShrink: 0,
      boxShadow: '0 0 12px var(--accent-glow)',
    }}>
      <div style={{ width: s * 0.14, height: s * 0.14, borderRadius: '50%', background: '#fff', position: 'absolute', top: s * 0.3, left: s * 0.24 }} />
      <div style={{ width: s * 0.14, height: s * 0.14, borderRadius: '50%', background: '#fff', position: 'absolute', top: s * 0.3, right: s * 0.24 }} />
      <div style={{ width: s * 0.25, height: s * 0.12, borderBottom: `2px solid #fff`, borderRadius: '0 0 50% 50%', position: 'absolute', bottom: s * 0.24 }} />
    </div>
  );
}
